package com.elitecore.netvertexproject;

public interface OnTaskComplete {
	 public void onGetBuildType(String result);
}
