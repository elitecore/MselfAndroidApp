package com.elitecore.netvertexproject;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertexproject.R;
import com.elitecore.netvertexproject.Services.MyBackgroundTask;
import com.elitecore.netvertexproject.XMLParse.AddonUnSubscriptionParser;
import com.elitecore.netvertexproject.constant.Constant;
import com.elitecore.netvertexproject.constant.SoapXML;

public class AddonUnsbscriptionAdpter extends ArrayAdapter<GetActiveAddon>
implements OnTaskComplete {

	public static List<GetActiveAddon> addon;

	private int layoutResourceId;
	public Context context;

	public String username;
	private View view;

	public AddonUnsbscriptionAdpter(Context context, int resource,
			List<GetActiveAddon> addonlist) {
		super(context, resource, addonlist);
		this.addon = addonlist;
		this.layoutResourceId = resource;
		this.context = context;
		SharedPreferences pref = getContext().getSharedPreferences(
				Loginactivity.MyPREFERENCES, 0);
		username = pref.getString(Loginactivity.Login_User, "");
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder viewHolder;

		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);

			viewHolder = new ViewHolder();

			viewHolder.addonname = (TextView) convertView
					.findViewById(R.id.txtaddonunsubscribe);
			viewHolder.addonexpdate = (TextView) convertView
					.findViewById(R.id.txtaddonexpdate);
			viewHolder.addonstartdate = (TextView) convertView
					.findViewById(R.id.txtaddonstartdate);
			viewHolder.addonunsubscribe = (Button) convertView
					.findViewById(R.id.btnaddonunsubscribe);

			convertView.setTag(viewHolder);

		}

		else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		GetActiveAddon currentaddon = getItem(position);
		final GetActiveAddon addonunsubs = addon.get(position);
		viewHolder.addonunsubscribe.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String addoname = addonunsubs.getPackage_name();
				String addonunsubsxml = SoapXML.getunsubscription(addoname,
						username);

				MyBackgroundTask services = new MyBackgroundTask(context,
						addonunsubsxml, Constant.SoapURLOCS,
						Constant.SoapActionOCS, AddonUnsbscriptionAdpter.this);
				services.execute();
				view = v;
			}

			private void startActivity(Intent i) {
				// TODO Auto-generated method stub

			}
		});
		if (convertView != null) {

			viewHolder.addonname.setText(currentaddon.getPackage_name()
					.toString());
			// viewHolder.pName.setText("");
			viewHolder.addonexpdate.setText(currentaddon.getValidToDate()
					.toString());
			viewHolder.addonstartdate.setText(currentaddon.getValidFromDate()
					.toString());

		}

		return convertView;
	}

	private class ViewHolder {
		TextView addonname;
		TextView addonexpdate;
		TextView addonstartdate;
		Button addonunsubscribe;
	}

	@Override
	public void onGetBuildType(String result) {
		// TODO Auto-generated method stub
		String response = result;

		try {
			System.out.println("Response=" + response);
			BufferedReader br = new BufferedReader(new StringReader(response));
			InputSource isr = new InputSource(br);
			AddonUnSubscriptionParser addonunsubsparser = new AddonUnSubscriptionParser();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(addonunsubsparser);
			reader.parse(isr);
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			View toastRoot = inflater.inflate(R.layout.toast_message_unsubscription_plan_success, null);
			Toast toast=new Toast( getContext());
			toast.setView(toastRoot);
			toast.setGravity(Gravity.BOTTOM, 10, 50);
			toast.setDuration(Toast.LENGTH_LONG);
			toast.show();
			Intent i = new Intent(view.getContext(), HomeActivity.class);
			view.getContext().startActivity(i);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
