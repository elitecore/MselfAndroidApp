package com.elitecore.netvertexproject.constant;

public class Constant {

	// webservice URL and action for authentication
	//public static final String SoapURL="http://192.168.2.22:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapURL="http://103.23.140.242:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapAction="http://192.168.2.22:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapAction="http://103.23.140.242:8586/sm/services/ParentalService?wsdl";
	public static final String SoapURL="http://203.88.129.43:8586/sm/services/ParentalService?wsdl";
	public static final String SoapAction="http://203.88.129.43:8586/sm/services/ParentalService?wsdl";
	public static final String SoapURLaddonsubs="http://203.88.129.43:8586/sm/services/SubscriptionService?wsdl";
	public static final String SoapActionaddonsubs="http://203.88.129.43:8586/sm/services/SubscriptionService?wsdl";
	public static final String SoapURLOCS="http://203.88.129.43:8992/Integrations/IntegrationWebService?wsdl";
	public static final String SoapActionOCS="http://203.88.129.43:8992/Integrations/IntegrationWebService?wsdl";
	public static final String SoapURLPLM="http://203.88.129.43:8992/ProductManagerAPIWebService?wsdl";
	public static final String SoapActionPLM="http://203.88.129.43:8992/ProductManagerAPIWebService?wsdl";
	public static final String Login_user="login_user";
	public static final String Login_user_password="login_user_password";
	public static final String BillDesk="https://www.billdesk.com/pgidsk/pgijsp/MerchantPaymentoption.jsp";
	public static final String Login_User = "login_user";
	public static final String Login_User_pwd = "login_user_pwd";
	public static final String Login_User_Billingdate = "login_user_billingdate";
	public static final String Login_User_CustomerType = "login_user_customertype";
	public static final String Login_User_Email = "login_user_email";
	public static final String Login_User_Subscriberpackage="login_user_subscriberpackage";
	public static final String MyPREFERENCES = "MyPrefs";
	public static final String MyServicealias = "MySeriveAlias";
	public static final String Service_alias = "ServiceAlias";
	public static final String MyUsername = "MyUsername";
	public static final String Login_User_Name = "login_user_name";
}
