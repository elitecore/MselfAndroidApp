package com.elitecore.netvertexproject;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetBalance;
import com.elitecore.netvertexproject.Services.MyBackgroundTask;
import com.elitecore.netvertexproject.XMLParse.AddonListParser;
import com.elitecore.netvertexproject.XMLParse.GetBalanceParse;
import com.elitecore.netvertexproject.constant.Constant;
import com.elitecore.netvertexproject.constant.SoapXML;

public class HomeActivity extends Activity implements OnTaskComplete {

	private TextView t1;
	SharedPreferences preference;
	public String subscriberidentity;

	private Button buttongetbal;
	private Button buttonaddonsubscription;
	public static ArrayList<GetBalance> balanceList;

	public static ArrayList<AddonList> addonsublist;

	public static ArrayList<GetActiveAddon> activeaddonlist;

	private String currentCall;
	private Button btnmyprofile;
	private Button btnmyusagepattern;
	private String servicealias;
	SharedPreferences pref;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_home);

		t1 = (TextView) findViewById(R.id.uname);

		pref = getSharedPreferences(Constant.MyServicealias, MODE_PRIVATE);



		preference=getSharedPreferences(Constant.MyUsername, MODE_PRIVATE);


		try {
			if (getIMSIFromEliteConnect() != null) {
				subscriberidentity = getIMSIFromEliteConnect();

				t1.setText("Welcome " + subscriberidentity + " !!");
				Editor editor;
				editor=preference.edit();
				editor.putString(Constant.Login_User_Name, subscriberidentity);
				editor.commit();
			}
		} catch (NullPointerException e) {
			Log.e("IMSI is NULL", e.toString());
			throw e;
		}
		currentCall = "AutoGetBal";
		String getbalxml = SoapXML.getbalance(subscriberidentity);
		MyBackgroundTask services = new MyBackgroundTask(HomeActivity.this,
				getbalxml, Constant.SoapURLOCS, Constant.SoapActionOCS,
				HomeActivity.this);
		services.execute();



		buttongetbal = (Button) findViewById(R.id.btngetbalance);
		buttongetbal.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				currentCall = "GetBal";
				String getbalxml = SoapXML.getbalance(subscriberidentity);
				MyBackgroundTask services = new MyBackgroundTask(
						HomeActivity.this, getbalxml, Constant.SoapURLOCS,
						Constant.SoapActionOCS, HomeActivity.this);
				services.execute();

			}
		});


		buttonaddonsubscription = (Button) findViewById(R.id.btnsubscription);
		buttonaddonsubscription.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				currentCall = "AddSub";
				if (currentCall.equals("AddSub")) {
					String addonsubsxml = SoapXML.getaddonsubscription();
					MyBackgroundTask services = new MyBackgroundTask(
							HomeActivity.this, addonsubsxml,
							Constant.SoapURLPLM, Constant.SoapActionPLM,
							HomeActivity.this);
					services.execute();
				}

			}

		});


		btnmyprofile = (Button) findViewById(R.id.btnmyprofile);
		btnmyprofile.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this, MyProfile.class);
				startActivity(intent);


			}

		});

		btnmyusagepattern = (Button) findViewById(R.id.btnmypatteren);
		btnmyusagepattern.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HomeActivity.this,
						MyUsagePatternAvailabe.class);
				startActivity(intent);
			}
		});

	}

	public String getIMSIFromEliteConnect() {

		Context con;

		String imsi = null;

		try {

			con = createPackageContext("com.elitecore.eliteconnect", 0);

			SharedPreferences pref = con.getSharedPreferences("ELITEIMSI",
					Context.MODE_PRIVATE);

			imsi = pref.getString("ELITEIMSI", "");

		}

		catch (NameNotFoundException e) {

			Log.e("Not data shared", e.toString());

		}

		return imsi;

	}


	@Override
	public void onGetBuildType(String result) {
		if (currentCall.equals("GetBal"))
			callGetBal(result);
		if (currentCall.equals("AddSub"))
			callAddOnSubscriber(result);

		if (currentCall.equals("AutoGetBal"))
			autoGetBal(result);


	}


	private void autoGetBal(String result) {
		String response1 = result;
		try {
			BufferedReader br = new BufferedReader(new StringReader(response1));
			InputSource isr = new InputSource(br);
			GetBalanceParse getBalanceParser = new GetBalanceParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(getBalanceParser);
			reader.parse(isr);
			balanceList = (ArrayList<GetBalance>) getBalanceParser.listbal;
			activeaddonlist = (ArrayList<GetActiveAddon>) getBalanceParser.addonunsubslist;
			if (activeaddonlist != null && !activeaddonlist.isEmpty()) {
				for (GetActiveAddon activeaddon : activeaddonlist) {
					servicealias = activeaddon.getServicealias();
					System.out.println("Servicealias=" + servicealias);

				}
				Editor editor;
				editor = pref.edit();
				editor.putString(Constant.Service_alias,servicealias);
				editor.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void callAddOnSubscriber(String result) {
		String response2 = result;

		try {

			BufferedReader br = new BufferedReader(new StringReader(response2));
			InputSource isr = new InputSource(br);
			AddonListParser addonsubsparser = new AddonListParser();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(addonsubsparser);
			reader.parse(isr);
			addonsublist = (ArrayList<AddonList>) addonsubsparser.addonlist;
			Intent intent = new Intent(HomeActivity.this, AddonDisplay.class);
			startActivity(intent);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	private void callGetBal(String result) {
		String response1 = result;
		try {

			BufferedReader br = new BufferedReader(new StringReader(response1));
			InputSource isr = new InputSource(br);
			GetBalanceParse getBalanceParser = new GetBalanceParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(getBalanceParser);
			reader.parse(isr);
			balanceList = (ArrayList<GetBalance>) getBalanceParser.listbal;
			activeaddonlist = (ArrayList<GetActiveAddon>) getBalanceParser.addonunsubslist;
			


			Intent intent = new Intent(HomeActivity.this, BalanceDisplay.class);

			startActivity(intent);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

}
