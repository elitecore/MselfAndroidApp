package com.elitecore.netvertexproject;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertexproject.R;

public class AddonUnsubscription extends ActionBarActivity {
	public static ArrayList<GetActiveAddon>addonunsubscriptionlist= new ArrayList<GetActiveAddon>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_addon_unsubscription);
		addonunsubscriptionlist=HomeActivity.activeaddonlist;
		ListView lst=(ListView)findViewById(R.id.listView3);
		if(addonunsubscriptionlist!=null)
		{
			AddonUnsbscriptionAdpter arp= new AddonUnsbscriptionAdpter(this, R.layout.activity_addon_unsbscription_adpter, addonunsubscriptionlist);
			lst.setAdapter(arp);			
		}
	}


}
