package com.elitecore.netvertexproject.XMLParse;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetBalance;

public class GetActiveAddonParse extends DefaultHandler {

	public GetBalance addonunsubs = null;

	public List<GetBalance> listaddon = new ArrayList<GetBalance>();

	// Stack<String> stack = new Stack<String>();
	StringBuilder builder;
	String packageName;

	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	Boolean isaddon = false;

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();

		if (qName.equals("packageData")) {
			addonunsubs = new GetBalance();
			// stack.push(qName);
			isaddon = true;
		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (qName.equals("packageData")) {
			listaddon.add(addonunsubs);

		}

	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
