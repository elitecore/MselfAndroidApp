package com.elitecore.netvertexproject;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetBalance;
import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.SubscriberProfile;
import com.elitecore.netvertexproject.R;
import com.elitecore.netvertexproject.Services.MyBackgroundTask;
import com.elitecore.netvertexproject.XMLParse.LoginXMLParse;
import com.elitecore.netvertexproject.constant.Constant;
import com.elitecore.netvertexproject.constant.SoapXML;

public class Loginactivity extends Activity implements OnTaskComplete {

	private Button button;
	private EditText txtuname;
	private EditText txtpwd;
	public static String username;
	public static String password;
	SharedPreferences pref;
	private String uname;
	private String pwd;
	public static ArrayList<GetBalance> lst;
	public static final String Login_User = "login_user";
	public static final String Login_User_pwd = "login_user_pwd";
	public static final String Login_User_Billingdate = "login_user_billingdate";
	public static final String Login_User_CustomerType = "login_user_customertype";
	public static final String Login_User_Email = "login_user_email";
	public static final String Login_User_Subscriberpackage="login_user_subscriberpackage";
	public static SubscriberProfile loggedInSubscriberProfile;
	public static final String MyPREFERENCES = "MyPrefs";
	private SubscriberProfile profile;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_loginactivity);

		pref = getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);
		/*
		 * if (pref.contains(Login_User)&& pref.contains(Login_User_pwd)) {
		 * Intent i = new Intent(Loginactivity.this,
		 * com.elitecore.netvertexproject.HomeActivity.class);
		 * 
		 * }
		 */

		button = (Button) findViewById(R.id.btnlogin);
		txtuname = (EditText) findViewById(R.id.txtUsername);
		txtpwd = (EditText) findViewById(R.id.txtPassword);
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				username=txtuname.getText().toString();
				password=txtpwd.getText().toString();

				//Request
				String soapXML=SoapXML.getLoginString(username, password);

				//BackgroundProcess of AsyncTask
				MyBackgroundTask services =new MyBackgroundTask(Loginactivity.this, soapXML, Constant.SoapURL, Constant.SoapAction, Loginactivity.this);
				services.execute();









				//				InputStream ipt;
				//				try {
				//					ipt = getAssets().open("balance.xml");
				//
				//					InputSource ipr = new InputSource(ipt);
				//					GetBalanceParse parse = new GetBalanceParse();
				//					SAXParserFactory factory = SAXParserFactory.newInstance();
				//					SAXParser sp = factory.newSAXParser();
				//					XMLReader reader = sp.getXMLReader();
				//					reader.setContentHandler(parse);
				//					reader.parse(ipr);
				//					lst = new ArrayList<GetBalance>();
				//					lst = (ArrayList<GetBalance>) parse.listbal;
				//					
				//					
				//					
				//					
				//					
				//					Intent intent = new Intent(Loginactivity.this,BalanceDisplay.class);
				//
				//					//intent.putParcelableArrayListExtra("PackageName", lst);
				//					startActivity(intent);
				//					
				//					
				//				} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}


		});

	}

	@Override
	public void onGetBuildType(String result) {
		// TODO Auto-generated method stub
		//Response
		String response= result;
		try
		{
			System.out.println("Response is="+response);

			BufferedReader br = new BufferedReader(new StringReader(response));
			InputSource isr=new InputSource(br); 

			LoginXMLParse parse=new LoginXMLParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader=sp.getXMLReader();
			reader.setContentHandler(parse);
			reader.parse(isr);

			profile=parse.subscriber;



			if(profile!=null)
			{
				if(profile.getSubscriberIdentity()!=null){
					loggedInSubscriberProfile=profile;
					System.out.println("User id="+profile.getSubscriberIdentity());
					uname=profile.getSubscriberIdentity().toString();
					pwd=profile.getPassword().toString();
					String billingdate=profile.getBillingDate().toString();
					String customertype=profile.getCustomerType();
					String email=profile.getEmail();
					String subscribepackage=profile.getSubscriberPackage();
					Editor editor;
					editor=pref.edit();
					editor.putBoolean("is_login", true);

					//					editor.putString(Constant.Login_user, uname);
					//					editor.putString(Constant.Login_user_password, pwd);
					editor.putString(Login_User, uname);
					editor.putString(Login_User_pwd, pwd);
					editor.putString(Login_User_Billingdate,billingdate);
					editor.putString(Login_User_CustomerType,customertype);
					editor.putString(Login_User_Email, email);
					editor.putString(Login_User_Subscriberpackage, subscribepackage);
					editor.commit();


					Intent intent= new Intent(Loginactivity.this,com.elitecore.netvertexproject.HomeActivity.class);

					startActivity(intent);


				} else {
					Toast toast=Toast.makeText( getApplicationContext(),"Username or Password is wrong", Toast.LENGTH_LONG);
					toast.setGravity(Gravity.CENTER, 0, 0);
					ImageView view = new ImageView(this);
					view.setImageResource(R.drawable.toast_message);
					toast.setView(view);
					toast.show();
				}
			} 
			else {

				Toast toast=new Toast( getApplicationContext());

				LayoutInflater inflater = getLayoutInflater();
				View toastRoot = inflater.inflate(R.layout.toast_message_login, null);

				toast.setView(toastRoot);
				toast.setGravity(Gravity.BOTTOM, 10, 50);
				toast.setDuration(Toast.LENGTH_LONG);
				toast.show();
			}
		}catch (Exception e)
		{
			Log.e("SubscriberProfile", "Exception parse xml :" + e);

		}
	}

}
