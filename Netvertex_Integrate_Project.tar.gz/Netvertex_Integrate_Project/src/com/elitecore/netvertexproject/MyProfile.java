package com.elitecore.netvertexproject;

import java.io.BufferedReader;
import java.io.StringReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.SubscriberProfile;
import com.elitecore.netvertexproject.Services.MyBackgroundTask;
import com.elitecore.netvertexproject.XMLParse.LoginXMLParse;
import com.elitecore.netvertexproject.constant.Constant;
import com.elitecore.netvertexproject.constant.SoapXML;

public class MyProfile extends ActionBarActivity implements OnTaskComplete{
	private TextView txtusername;
	private TextView txtbiilingdate;
	private TextView txtcustomertype;
	private TextView txtemail;
	private TextView txtsubscriberpackage;
	public static String username;
	public static String password;
	private String billingdate;
	private String customertype;
	private String email;
	private String subscriberpackage;
	private SubscriberProfile profile;
	SharedPreferences pref,peference;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_my_profile);

		txtusername=(TextView)findViewById(R.id.txtmyprofileusername);
		txtbiilingdate=(TextView)findViewById(R.id.txtmyprofilebiililngdate);
		txtcustomertype=(TextView)findViewById(R.id.txtmyprofilecustomertype);
		txtemail=(TextView)findViewById(R.id.txtmyprofileemail);
		txtsubscriberpackage=(TextView)findViewById(R.id.txtmyprofilepackagename);
		password="corewifi";
		peference=getSharedPreferences(Constant.MyUsername, MODE_PRIVATE);
		username=peference.getString(Constant.Login_User_Name, "");
		String soapXML=SoapXML.getLoginString(username, password);
		MyBackgroundTask services =new MyBackgroundTask(MyProfile.this, soapXML, Constant.SoapURL, Constant.SoapAction, MyProfile.this);
		services.execute();
	}






	@Override
	public void onGetBuildType(String result) {
		// TODO Auto-generated method stub
		//Response
		String response= result;
		try
		{
			System.out.println("Response is="+response);

			BufferedReader br = new BufferedReader(new StringReader(response));
			InputSource isr=new InputSource(br); 

			LoginXMLParse parse=new LoginXMLParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader=sp.getXMLReader();
			reader.setContentHandler(parse);
			reader.parse(isr);

			profile=parse.subscriber;

			billingdate=profile.getBillingDate().toString();
			customertype=profile.getCustomerType().toString();
			email=profile.getEmail().toString();
			subscriberpackage=profile.getSubscriberPackage();
			txtusername.setText(username);

			txtbiilingdate.setText(billingdate + "    (Every Month)");
			txtcustomertype.setText(customertype);
			txtemail.setText(email);
			txtsubscriberpackage.setText(subscriberpackage);
		}


		catch (Exception e)
		{
			Log.e("SubscriberProfile", "Exception parse xml :" + e);

		}
	}




}