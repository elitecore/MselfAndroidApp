package com.elitecore.netvertexproject;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertexporject_sm.ws.cxfws.ssp.parental.GetBalance;

public class MainActivity extends Activity {
	private static final long DELAY = 3000;
	private boolean scheduled = false;
	private Timer splashTimer;
	SharedPreferences pref;
	String uname;
	public Context context;
	String servicealias;
	public static ArrayList<GetBalance> balanceList;
	public static ArrayList<GetActiveAddon> activeaddonlist;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		splashTimer =new Timer();

		splashTimer.schedule(new TimerTask()
		{

			@Override
			public void run() {
				// TODO Auto-generated method stub
				pref=getSharedPreferences(Loginactivity.MyPREFERENCES, MODE_PRIVATE);
				uname=pref.getString(Loginactivity.Login_User, "");
				MainActivity.this.finish();
				if(pref.contains(Loginactivity.Login_User)&& pref.contains(Loginactivity.Login_User_pwd))
				{

					startActivity(new Intent(MainActivity.this,HomeActivity.class));
				}
				else
				{
					startActivity(new Intent(MainActivity.this,Loginactivity.class));
				}
			}
		},DELAY);


	}





	@Override
	protected void onDestroy() {

		super.onDestroy();
		if (scheduled)
			splashTimer.cancel();
		splashTimer.purge();

	}

}

