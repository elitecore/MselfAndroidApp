/** Automatically generated file. DO NOT MODIFY */
package com.elitecore.netvertexproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}