/** Automatically generated file. DO NOT MODIFY */
package com.elitecore.netvertex_ocs_billing_LTE_project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}