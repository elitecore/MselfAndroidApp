package com.elitecore.netvertex.ocs.billing.XMLParse;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex.ocs.billing.pojo.AddonSubscription;

public class AddonSubscriptionParser extends DefaultHandler {

	//AddonSubscription response parser
	
	StringBuilder builder;

	public AddonSubscription addsubs = null;

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();

		if (localName.equals("responseMessage")) {
			addsubs = new AddonSubscription();

		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.equalsIgnoreCase("responseMessage")) {

			addsubs.setResponse(builder.toString());
		}
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
