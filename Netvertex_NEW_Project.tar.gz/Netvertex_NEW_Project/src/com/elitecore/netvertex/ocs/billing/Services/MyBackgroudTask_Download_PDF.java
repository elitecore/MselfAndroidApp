package com.elitecore.netvertex.ocs.billing.Services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.elitecore.netvertex.ocs.billing.OnTaskComplete;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

public class MyBackgroudTask_Download_PDF extends AsyncTask<String, String, String> {
	public static final int DIALOG_DOWNLOAD_PROGRESS = 0;
	private ProgressDialog mProgressDialog;
	private String urlString;
	private Context context;
	@Override
    protected void onPreExecute() {
        super.onPreExecute();
        showDialog(DIALOG_DOWNLOAD_PROGRESS);
    }
	
	private void showDialog(int dialogDownloadProgress) {
		// TODO Auto-generated method stub
		
	}
	public MyBackgroudTask_Download_PDF(Context context,String url) {
		this.context = context;
		this.urlString = url;
	}

	@Override
	protected String doInBackground(String... string) {
		int count;
		try{
		URL url = new URL(urlString);
		HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

		urlConnection.setRequestMethod("GET");
        urlConnection.setDoOutput(true);
        urlConnection.connect();
        
        String SDcard=Environment.getExternalStorageState().toString();
        File mFolder = new File(SDcard+"/bill/");
        if (!mFolder.exists()) {
            mFolder.mkdir();
        }
        
        String bill="bill.pdf";
        File file = new File(mFolder.getAbsolutePath(), bill);
        file.createNewFile();
        FileOutputStream Output = new FileOutputStream(file);
        InputStream inputStream = urlConnection.getInputStream();
        int totalSize = urlConnection.getContentLength();
        int downloadedSize = 0;
        byte[] buffer = new byte[1024 * 1024];
        long total = 0; 
        
        while ((count = inputStream.read(buffer)) != -1) {
            total += count;
            publishProgress(""+(int)((total*100)/totalSize));
            Output.write(buffer, 0, count);
        }

        Output.flush();
        Output.close();
        inputStream.close();
   


		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	 protected void onProgressUpdate(String... progress) {
         Log.d("ANDRO_ASYNC",progress[0]);
         mProgressDialog.setProgress(Integer.parseInt(progress[0]));
    }

    @Override
    protected void onPostExecute(String unused) {
        dismissDialog(DIALOG_DOWNLOAD_PROGRESS);
    }

	private void dismissDialog(int dialogDownloadProgress) {
		// TODO Auto-generated method stub
		
	}
}