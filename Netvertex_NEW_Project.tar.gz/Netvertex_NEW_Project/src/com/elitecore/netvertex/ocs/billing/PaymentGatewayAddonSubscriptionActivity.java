package com.elitecore.netvertex.ocs.billing;

import org.apache.http.util.EncodingUtils;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.billdesk.pgidsk.PGIUtil;
import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.constant.Constant;

public class PaymentGatewayAddonSubscriptionActivity extends ActionBarActivity {
	
	//Payment Gateway configuration for AddonSubscrption
	
	public static String postdata;
	SharedPreferences preference,pref;
	private String strSALTKEY;
	private String username;
	private WebView webView;
	private String servicealias;
	private String addonname;
	private Double totaladdoncharge;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_payment_gateway);

		preference = getSharedPreferences(Constant.MyLoginPREFERENCES, 0);
		username = preference.getString(Constant.Login_User, "");
		pref = getSharedPreferences(Constant.MyServicealias,0);
		servicealias=pref.getString(Constant.Service_alias, "");
		addonname=AddonActivityAdpter.addonStr;
		totaladdoncharge=AddonActivityAdpter.totalcharge;
		webView = (WebView) findViewById(R.id.webView2);
		strSALTKEY = "e4QeKCM3RJID";

		String msgstring = "IDEAWIFI|" + username + "|NA|" + totaladdoncharge + "|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/?addonname=" + addonname +':' +servicealias +':'+username + "";
		System.out.println("MessageString=" + msgstring);
		String checkSum = PGIUtil.doDigest(msgstring, strSALTKEY);
		System.out.println("Checksum" + checkSum);
		postdata = "msg=IDEAWIFI|"+ username+ "|NA|" + totaladdoncharge + "|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/?addonname=" + addonname + ':' +servicealias +':'+ username + "|" + checkSum + "";
		System.out.println(postdata);

		webView.postUrl("https://www.billdesk.com/pgidsk/PGIMerchantPayment",EncodingUtils.getBytes(postdata, "BASE64"));
		webView.setWebViewClient(new WebViewClient() {

			
		}

		);

		webView.getSettings().setLoadsImagesAutomatically(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webView.getSettings().setBuiltInZoomControls(true);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setLoadWithOverviewMode(true);
		webView.getSettings().setUseWideViewPort(true);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		webView.getSettings().getLayoutAlgorithm();
		webView.getSettings().setDomStorageEnabled(true);

		
		
		
	}
	
	
}
