package com.elitecore.netvertex.ocs.billing;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.constant.Constant;

public class MyProfileActivity extends ActionBarActivity {

	//User Profile
	
	SharedPreferences pref;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_my_profile);

		TextView txtusername = (TextView) findViewById(R.id.txtmyprofileusername);
		TextView txtbiilingdate = (TextView) findViewById(R.id.txtmyprofilebiililngdate);
		TextView txtcustomertype = (TextView) findViewById(R.id.txtmyprofilecustomertype);
		TextView txtemail = (TextView) findViewById(R.id.txtmyprofileemail);
		TextView txtsubscriberpackage = (TextView) findViewById(R.id.txtmyprofilepackagename);
		pref = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		String username = pref.getString(Constant.Login_User, "");
		String billingdate = pref.getString(Constant.Login_User_Billingdate, "");
		String customertype = pref.getString(Constant.Login_User_CustomerType,"");
		String email = pref.getString(Constant.Login_User_Email, "");
		String subscriberpackage = pref.getString(Constant.Login_User_Subscriberpackage, "");

		txtusername.setText(username);

		txtbiilingdate.setText(billingdate + "    (Every Month)");
		txtcustomertype.setText(customertype);
		txtemail.setText(email);
		txtsubscriberpackage.setText(subscriberpackage);
	}

}
