package com.elitecore.netvertex.ocs.billing.Services;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import com.elitecore.netvertex.ocs.billing.OnTaskComplete;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

public class MyBackgroundTask extends AsyncTask<String, Integer, String> {
	
	//AsyncTask for calling PCRF and OCS API
	
	private ProgressDialog dialog;
	private Context context;
	private String soapxml;
	private String urlString;
	private String soapAction;
	private String response;
	OnTaskComplete callBack;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public MyBackgroundTask(Context context, String soapxml, String url,
			String soapAction, OnTaskComplete callBack) {
		this.context = context;
		this.soapxml = soapxml;
		this.urlString = url;
		this.soapAction = soapAction;
		this.callBack = callBack;
	}

	protected void onPreExecute() {
		dialog = ProgressDialog.show(context, "Processing", "Please Wait");
	}

	protected String doInBackground(String... strings) {
		String response = null;
		InputStream stream = null;

		URL url = null;
		try {
			url = new java.net.URL(urlString);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		java.net.URLConnection conn;
		try {
			conn = url.openConnection();
//			System.out.println("Permission String: "+ conn.getPermission().toString());
//			System.out.println("Permission Name: "+ conn.getPermission().getName());
//			System.out.println("URL : " + conn.getURL());

			// stream = conn.getInputStream();

			conn.setDoOutput(true);
			conn.setRequestProperty("SOAPAction", soapAction);
			// Send the request
			java.io.OutputStreamWriter wr = new java.io.OutputStreamWriter(
					conn.getOutputStream());
			wr.flush();
			wr.write(soapxml);
			wr.flush();
			// Read the response
			stream = conn.getInputStream();
			java.io.BufferedReader rd = new java.io.BufferedReader(
					new java.io.InputStreamReader(stream));
			String line;
			StringBuilder sb = new StringBuilder();
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}
			response = sb.toString();
			setResponse(response);
			stream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return response;

	}

	protected void onPostExecute(String result) {
		if (dialog.isShowing()) {
			dialog.dismiss();
		}
		callBack.onGetBuildType(result);
	}

}
