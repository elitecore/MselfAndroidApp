package com.elitecore.netvertex.ocs.billing;

import org.apache.http.util.EncodingUtils;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.billdesk.pgidsk.PGIUtil;
import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.constant.Constant;

public class PaymentGatewayBillPaymentActivity extends ActionBarActivity {
	
	//Payment Gateway configuration for Bill Payment
	
	private String strSALTKEY;
	private String useraccountname;
	private String accountnumber;
	private String billamount;
	private Double paymentbillamount;
	private String username;
	private WebView webView;
	private String billnumber;
	public static String postdata;
	SharedPreferences preference;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		preference = getSharedPreferences(Constant.MyLoginPREFERENCES, 0);
		setContentView(R.layout.activity_payment_gateway_bill_payment);
		username = preference.getString(Constant.Login_User, "");
		useraccountname=preference.getString(Constant.Login_User_Name,"");
		accountnumber=preference.getString(Constant.Login_User_CUI, "");
		
		webView = (WebView) findViewById(R.id.billpaymentwebview);
		
		strSALTKEY = "e4QeKCM3RJID";
		billamount=(BillPaymentActivityAdpter.billamount).toString();
		paymentbillamount=BillPaymentActivityAdpter.paymentbillamount/100;
		billnumber=BillPaymentActivityAdpter.paymentbillnumber;
		String msgstring = "IDEAWIFI|" + username + "|NA|2|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/makePayment.jsp?accountname=" + useraccountname +':' +accountnumber +':'+billnumber+':'+ billamount+ "";
		System.out.println("MessageString=" + msgstring);
		String checkSum = PGIUtil.doDigest(msgstring, strSALTKEY);
		System.out.println("Checksum" + checkSum);
		postdata = "msg=IDEAWIFI|"+ username+ "|NA|2|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/makePayment.jsp?accountname=" + useraccountname + ':' +accountnumber+':' + billnumber+':'+billamount + "|" + checkSum + "";
		System.out.println(postdata);

		webView.postUrl("https://www.billdesk.com/pgidsk/PGIMerchantPayment",
				EncodingUtils.getBytes(postdata, "BASE64"));
		
	webView.setWebViewClient(new WebViewClient() {

			
		}

		);
		webView.getSettings().setLoadsImagesAutomatically(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webView.getSettings().setBuiltInZoomControls(true);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setLoadWithOverviewMode(true);
		webView.getSettings().setUseWideViewPort(true);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		webView.getSettings().getLayoutAlgorithm();
		webView.getSettings().setDomStorageEnabled(true);

	
	
	}

	
}
