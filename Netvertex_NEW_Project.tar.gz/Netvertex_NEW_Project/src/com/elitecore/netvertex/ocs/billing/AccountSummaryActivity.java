package com.elitecore.netvertex.ocs.billing;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.elitecore.netvertex.ocs.billing.Services.MyBackgroundTask_Billing;
import com.elitecore.netvertex.ocs.billing.constant.Constant;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatement;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementCredit;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementDebit;

@SuppressLint("SimpleDateFormat")
public class AccountSummaryActivity extends ActionBarActivity implements OnTaskComplete{

	public EditText fromdate;
	public EditText todate;
	private Button buttonfromdate;
	private Button buttontodate;
	public static String startdate;
	public static String enddate;
	private Button submit;
	private String amount;
	private String currency;
	private String category;
	private String transactiondate;
	private String transactiontype;
	public static ArrayList<GetAccountStatementCredit> creditList = new ArrayList<GetAccountStatementCredit>();
	public static ArrayList<GetAccountStatementDebit> debitList = new ArrayList<GetAccountStatementDebit>();
	public static ArrayList<GetAccountStatement> accStatementList = new ArrayList<GetAccountStatement>();
	public String accountnum;
	
	public static ArrayList<GetAccountStatement> accStatement;
	private Boolean isInternetPresent = false;
	
	
	SharedPreferences pref,preference;
	final Calendar myCalendar = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_account_summary);
		
		fromdate=(EditText)findViewById(R.id.datepickedfromdate);
		todate=(EditText)findViewById(R.id.datepickedtodate);

		buttonfromdate=(Button)findViewById(R.id.btnfromdate);
		buttontodate=(Button)findViewById(R.id.btntodate);
		pref = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		accountnum=pref.getString(Constant.Login_User_CUI, "");
		preference=getSharedPreferences(Constant.Transactiondate, MODE_PRIVATE);
		
		//Calendar Control
		final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				myCalendar.set(Calendar.YEAR, year);
				myCalendar.set(Calendar.MONTH, monthOfYear);
				myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
				updateLabel();


			}

		};
		final DatePickerDialog.OnDateSetListener datedialog = new DatePickerDialog.OnDateSetListener() {

			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				myCalendar.set(Calendar.YEAR, year);
				myCalendar.set(Calendar.MONTH, monthOfYear);
				myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
				updateLabeltodate();



			}

		};

		buttonfromdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new DatePickerDialog(AccountSummaryActivity.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
						myCalendar.get(Calendar.DAY_OF_MONTH)).show();
			}
		});
		buttontodate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				new DatePickerDialog(AccountSummaryActivity.this, datedialog, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
						myCalendar.get(Calendar.DAY_OF_MONTH)).show();

			}
		});
		submit=(Button)findViewById(R.id.btnsubmit);
		submit.setOnClickListener(new OnClickListener() {

			

				@Override
				public void onClick(View v) {
					//Validation raise when Editext is blank
					if(fromdate.getText().toString().trim().equals("") || todate.getText().toString().trim().equals("")){
						Toast toast = new Toast(getApplicationContext());
						LayoutInflater inflater = getLayoutInflater();
						View toastRoot = inflater.inflate(R.layout.toast_message_textview_blank,null);
						toast.setView(toastRoot);
						toast.setGravity(Gravity.BOTTOM, 10, 50);
						toast.setDuration(Toast.LENGTH_LONG);
						toast.show();
					}
					else{
					
					startdate = fromdate.getText().toString();
			        enddate= todate.getText().toString();
			        Editor editor;
			        editor=preference.edit();
			        editor.putString(Constant.Startdate, startdate);
			        editor.putString(Constant.Enddate, enddate);
			        editor.commit();
					MyBackgroundTask_Billing service= new MyBackgroundTask_Billing(AccountSummaryActivity.this,accountnum,startdate,enddate,Constant.SoapURLBilling,Constant.SoapActionBilling,Constant.Soap_NAMESPACE_Billing,Constant.Soap_METHOD_NAME_Billing,AccountSummaryActivity.this);
					service.execute();
					}
					
				}
				
        });
		
		}



	

	private void updateLabel() {

		String myFormat = "yyyy-MM-dd"; 
		SimpleDateFormat sdf = new SimpleDateFormat(myFormat);

		fromdate.setText(sdf.format(myCalendar.getTime()));


	}
	private void updateLabeltodate() {

		String myFormat = "yyyy-MM-dd"; 
		SimpleDateFormat sdf = new SimpleDateFormat(myFormat);


		todate.setText(sdf.format(myCalendar.getTime()));
	}




	@Override
	public void onGetBuildType(String result) {
		try {
			creditList.clear();
			debitList.clear();
		String response =result;
		
		MyBackgroundTask_Billing.envelope.dotNet = false;
		MyBackgroundTask_Billing.envelope.setOutputSoapObject(response);
		SoapObject resultRequestSOAP;
		
			resultRequestSOAP = (SoapObject)MyBackgroundTask_Billing.envelope.bodyIn;
		
		SoapObject root = (SoapObject) resultRequestSOAP.getProperty(0);
		GetAccountStatement accStatement =new GetAccountStatement();
		

		for (int i = 0; i < root.getPropertyCount(); i++) {
			Object property = root.getProperty(i);
			PropertyInfo pi1 = new PropertyInfo();
			root.getPropertyInfo(i, pi1);
			if (property instanceof SoapObject) {
				SoapObject accountstatementproperty = (SoapObject) property;
				amount = accountstatementproperty.getProperty("amount").toString();
				currency = accountstatementproperty.getProperty("currency").toString();
				category = accountstatementproperty.getProperty("documentCategory").toString();
				transactiondate= accountstatementproperty.getProperty("postDate").toString();
				transactiontype=accountstatementproperty.getProperty("documentType").toString();
				if (pi1.getName().equals("creditDocumentVO")) {
					GetAccountStatementCredit credit = new GetAccountStatementCredit();
					// TODO set values
					credit.setAmount(Double.parseDouble(amount));
					credit.setCurrency(currency);
					credit.setCategory(category);
					credit.setTransactiontype(transactiontype);
					credit.setTransactiondate(transactiondate);
					creditList.add(credit);
				} else if (pi1.getName().equals("debitDocumentVO")) {
					GetAccountStatementDebit debit = new GetAccountStatementDebit();
					// TODO set values
					debit.setAmount(Double.parseDouble(amount));
					debit.setCurreny(currency);
					debit.setCategory(category);
					debit.setTransactiontype(transactiontype);
					debit.setTransactiondate(transactiondate);
					debitList.add(debit);
				}
				
			}
		}
		accStatement.setAccountcreditlist(creditList);
		accStatement.setAccountdebitlist(debitList);
		accStatementList.add(accStatement);
		Intent intent= new Intent(AccountSummaryActivity.this,AccountSummaryListActivity.class);
		startActivity(intent);
		
	
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
} 

}





