package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class GetActiveAddon implements Parcelable {
	//Active Addon List pojo
	public static final long serialVersionUID = 1L;

	private String package_name = "";
	private String validToDate;
	private String validFromDate;
	private Integer priority;
	private String servicealias = "";
	private String service_alias_set = "";

	public String getService_alias_set() {
		return service_alias_set;
	}

	public void setService_alias_set(String service_alias_set) {
		this.service_alias_set = service_alias_set;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getServicealias() {
		return servicealias;
	}

	public void setServicealias(String servicealias) {
		this.servicealias = servicealias;
	}

	public String getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}

	public GetActiveAddon(Parcel in) {
		readFromParcel(in);
	}

	public GetActiveAddon() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {

		setPackage_name(in.readString());
		setValidToDate(in.readString());
		setValidToDate(in.readString());

	}

	public String getPackage_name() {
		return package_name;
	}

	public void setPackage_name(String package_name) {
		this.package_name = package_name;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeString(package_name);
		dest.writeString(validToDate);
		dest.writeString(validFromDate);
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetActiveAddon createFromParcel(Parcel in) {
			return new GetActiveAddon(in);
		}

		public GetActiveAddon[] newArray(int size) {
			return new GetActiveAddon[size];
		}
	};

	public String getValidToDate() {
		return validToDate;
	}

	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}

}
