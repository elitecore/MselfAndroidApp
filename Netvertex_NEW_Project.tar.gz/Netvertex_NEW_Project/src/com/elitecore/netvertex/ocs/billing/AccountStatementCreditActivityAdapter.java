package com.elitecore.netvertex.ocs.billing;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementCredit;


public class AccountStatementCreditActivityAdapter extends ArrayAdapter<GetAccountStatementCredit> {

	//AccountSummaryActivity Credit List Array Adapter
	
	private List<GetAccountStatementCredit> accountcreditsummary;
	private int layoutResourceId;
	private Context context;
	View view;
	Double amount;
	String date;
	Date dt;
	String description;
	SimpleDateFormat simpledateformate= new SimpleDateFormat("dd-mm-yyyy");

	public AccountStatementCreditActivityAdapter(Context context, int resource,
			List<GetAccountStatementCredit> accountstatement) {
		super(context, resource, accountstatement);
		this.context = context;
		this.accountcreditsummary = accountstatement;
		this.layoutResourceId = resource;

	}
	//Create View and set value in controls
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);

			viewHolder = new ViewHolder();
			viewHolder.transaction=(TextView)convertView.findViewById(R.id.txttransaction);
			viewHolder.amount = (TextView) convertView
					.findViewById(R.id.txtamount);
			viewHolder.date = (TextView) convertView.findViewById(R.id.txtdate);
			viewHolder.description = (TextView) convertView
					.findViewById(R.id.txtdescription);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		//Iterate value from (GetAccountStatementCredit) pojo by it's position
		final GetAccountStatementCredit currentaccountcreditstatement = getItem(position);
		if (convertView != null) {
			
			amount = currentaccountcreditstatement.getAmount()/100;
			date = currentaccountcreditstatement.getTransactiondate();
			description = currentaccountcreditstatement.getCategory();
			
			viewHolder.transaction.setText((position+1)+".");
			viewHolder.amount.setText(String.valueOf(amount)+"  "+currentaccountcreditstatement.getCurrency());


			viewHolder.date.setText(date);

			viewHolder.description.setText(currentaccountcreditstatement.getTransactiontype());
		}
		return convertView;
	}

	public class ViewHolder {
		TextView transaction;
		TextView amount;
		TextView date;
		TextView description;
	}
}
