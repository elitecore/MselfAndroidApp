package com.elitecore.netvertex.ocs.billing;

import javax.swing.text.TableView;

import android.support.v7.app.ActionBarActivity;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup.LayoutParams;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class BillTransaction extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill_transaction);
	
	TableLayout table;
	table=(TableLayout)findViewById(R.id.tabletrasaction);
	TableRow tr_head=new TableRow(BillTransaction.this);
	tr_head.setId(10);
	tr_head.setBackgroundColor(Color.BLUE);
	tr_head.setLayoutParams(new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
	TextView date=new TextView(BillTransaction.this);
	date.setId(20);
	date.setText("Date");
	date.setTextColor(Color.WHITE);
	date.setPadding(5, 5, 5, 5);
	tr_head.addView(date);
	
	TextView amount=new TextView(BillTransaction.this);
	amount.setId(20);
	amount.setText("Date");
	amount.setTextColor(Color.WHITE);
	amount.setPadding(5, 5, 5, 5);
	tr_head.addView(amount);
	
	TextView descrption=new TextView(BillTransaction.this);
	descrption.setId(20);
	descrption.setText("Date");
	descrption.setTextColor(Color.WHITE);
	descrption.setPadding(5, 5, 5, 5);
	tr_head.addView(descrption);
	
	
	table.addView(tr_head,new TableLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT));
	for(int i=0 ;i<HomeActivity.viewbilllist.size();i++){
	TableRow tr = new TableRow(this);
	 tr.setBackgroundColor(Color.BLACK);
	tr.setLayoutParams(new LayoutParams(
	LayoutParams.FILL_PARENT,
	LayoutParams.WRAP_CONTENT));
	}
	}

	
}
