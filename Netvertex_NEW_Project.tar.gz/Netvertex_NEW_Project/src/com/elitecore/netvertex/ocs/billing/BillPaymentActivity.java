package com.elitecore.netvertex.ocs.billing;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.ListView;

public class BillPaymentActivity extends ActionBarActivity {
	
	//Bill Payment Activity

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill_payment);
		
		ListView lstviewbill= (ListView)findViewById(R.id.listViewbill);
		
		if(HomeActivity.viewbilllist!=null){
			BillPaymentActivityAdpter arp= new BillPaymentActivityAdpter(BillPaymentActivity.this, R.layout.activity_bill_payment_adpter,HomeActivity.viewbilllist);
			lstviewbill.setAdapter(arp);
		}

	}


}
