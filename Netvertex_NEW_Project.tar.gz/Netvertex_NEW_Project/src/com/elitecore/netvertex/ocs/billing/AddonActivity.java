package com.elitecore.netvertex.ocs.billing;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;

import com.elitecore.netvertex.ocs.billing.HomeActivity;
import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.pojo.AddonList;

public class AddonActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_addon_display);

		ArrayList<AddonList> addonsubscriptionlist = HomeActivity.addonsublist;
		ListView lst = (ListView) findViewById(R.id.listView2);
		if (addonsubscriptionlist != null) {
			AddonActivityAdpter arp = new AddonActivityAdpter(this,R.layout.activity_addon_display_adpter,addonsubscriptionlist);
			lst.setAdapter(arp);
		}
	}
}
