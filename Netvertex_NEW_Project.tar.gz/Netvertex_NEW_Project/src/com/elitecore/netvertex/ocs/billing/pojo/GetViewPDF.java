package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class GetViewPDF implements Parcelable {
	
	public static final long serialVersionUID = 1L;

	private String path = "";
	

	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public GetViewPDF(Parcel in) {
		readFromParcel(in);
	}

	public GetViewPDF() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {

		setPath(in.readString());
		

	}

	

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeString(path);
		
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetActiveAddon createFromParcel(Parcel in) {
			return new GetActiveAddon(in);
		}

		public GetActiveAddon[] newArray(int size) {
			return new GetActiveAddon[size];
		}
	};

	

}
