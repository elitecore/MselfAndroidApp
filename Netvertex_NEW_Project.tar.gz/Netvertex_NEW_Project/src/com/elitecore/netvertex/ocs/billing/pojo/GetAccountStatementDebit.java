package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class GetAccountStatementDebit implements Parcelable {
	
	//Account Statement Debit Transaction List pojo
	
	public static final long serialVersionUID = 1L;
	protected Double amount = 0.0;

	protected String curreny = "";
	protected String category = "";
	protected String transactiontype="";
	protected String receipt="";
	protected String transactiondate="";

	
		public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public String getCurreny() {
		return curreny;
	}


	public void setCurreny(String curreny) {
		this.curreny = curreny;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getTransactiontype() {
		return transactiontype;
	}


	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}


	public String getReceipt() {
		return receipt;
	}


	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}


	public String getTransactiondate() {
		return transactiondate;
	}


	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}


		public GetAccountStatementDebit(Parcel in) {
		readFromParcel(in);
	}
		public GetAccountStatementDebit() {
			// TODO Auto-generated constructor stub
		}
	private void readFromParcel(Parcel in) {
		setAmount(in.readDouble());
		setCurreny(in.readString());
		setCategory(in.readString());
		setReceipt(in.readString());
		setTransactiontype(in.readString());
		setTransactiontype(in.readString());
		
	}

	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeDouble(amount);
		dest.writeString(curreny);
		dest.writeString(category);
		dest.writeString(receipt);
		dest.writeString(transactiondate);
		dest.writeString(transactiontype);
		
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetAccountStatementDebit createFromParcel(Parcel in) {
			return new GetAccountStatementDebit(in);
		}

		public GetAccountStatementDebit[] newArray(int size) {
			return new GetAccountStatementDebit[size];
		}
	};

	
}
