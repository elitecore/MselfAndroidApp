package com.elitecore.netvertex.ocs.billing.constant;

public class SoapXML {

	public static String getLoginString(String username, String password) {
		String soapXML = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:par=\"http://parental.ssp.cxfws.ws.netvertexsm.elitecore.com/\">";

		soapXML += " <soap:Header/>";
		soapXML += "<soap:Body>";
		soapXML += "<par:wsAuthenticate>";
		soapXML += "<userName>" + username + "</userName>";
		soapXML += "<password>" + password + "</password>";
		soapXML += "</par:wsAuthenticate>";
		soapXML += "</soap:Body>";
		soapXML += "</soap:Envelope>";
		return soapXML;

	}

	public static String getbalance(String subidentity) {
		String soapXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://soap.crestelocs.elitecore.com/\">";

		soapXML += " <soapenv:Header/>";
		soapXML += "<soapenv:Body>";
		soapXML += "<soap:viewCustomer>";
		soapXML += "<arg0>1";
		soapXML += "</arg0>";
		soapXML += "<arg1>";
		soapXML += "<balanceData>";
		soapXML += "<balanceTypeId>2";
		soapXML += "</balanceTypeId>";
		soapXML += "</balanceData>";
		soapXML += "<subscriberIdentifier>" + subidentity
				+ "</subscriberIdentifier>";
		// soapXML+="<fromDate>"+ currentdatetime + "</fromDate>";
		soapXML += "</arg1>";
		soapXML += "</soap:viewCustomer>";
		soapXML += "</soapenv:Body>";
		soapXML += "</soapenv:Envelope>";
		return soapXML;

	}

	public static String getaddonsubscription() {
		String soapXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://soap.billing.elitecore.com/\">";

		soapXML += " <soapenv:Header/>";
		soapXML += "<soapenv:Body>";
		soapXML += "<soap:getSpecificProdOfferDetails>";
		soapXML += "<arg0>";
		soapXML += "<productCategoryNames>Add-on";
		soapXML += "</productCategoryNames>";
		soapXML += "</arg0>";
		soapXML += "</soap:getSpecificProdOfferDetails>";
		soapXML += "</soapenv:Body>";
		soapXML += "</soapenv:Envelope>";
		return soapXML;

	}

	public static String getaddbuy(String Addon, String username) {
		String soapXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://soap.crestelocs.elitecore.com/\">";

		soapXML += " <soapenv:Header/>";
		soapXML += "<soapenv:Body>";
		soapXML += " <soap:updateCustomer>";
		soapXML += "<arg0>5";
		soapXML += "</arg0>";
		soapXML += "<arg1>";
		soapXML += " <packageData>";
		soapXML += " <packageName>" + Addon + "</packageName>";
		soapXML += "<serviceAlias>LDATA</serviceAlias>";

		soapXML += " </packageData>";
		soapXML += "<subscriberIdentifier>" + username
				+ "</subscriberIdentifier>";
		soapXML += "</arg1>";
		soapXML += " </soap:updateCustomer>";
		soapXML += "</soapenv:Body>";
		soapXML += "</soapenv:Envelope>";
		return soapXML;

	}

	public static String getunsubscription(String addonname, String username) {
		String soapXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://soap.crestelocs.elitecore.com/\">";

		soapXML += " <soapenv:Header/>";
		soapXML += "<soapenv:Body>";
		soapXML += " <soap:updateCustomer>";
		soapXML += "<arg0>9";
		soapXML += "</arg0>";
		soapXML += "<arg1>";
		soapXML += " <packageData>";
		soapXML += " <packageName>" + addonname + "</packageName>";
		soapXML += "<serviceAlias>LDATA</serviceAlias>";

		soapXML += " </packageData>";
		soapXML += "<userName>" + username + "</userName>";
		soapXML += "</arg1>";
		soapXML += " </soap:updateCustomer>";
		soapXML += "</soapenv:Body>";
		soapXML += "</soapenv:Envelope>";
		return soapXML;

	}

	public static String getAddonSubscriptionpcrf(String addonname,
			String username) {
		String soapXML = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:sub=\"http://subscription.ssp.cxfws.ws.netvertexsm.elitecore.com/\">";

		soapXML += " <soap:Header/>";
		soapXML += "<soap:Body>";
		soapXML += "<sub:wsSubscribeAddOnByName>";
		soapXML += "<subscriberID>" + username + "</subscriberID>";
		soapXML += "<addOnPackageName>" + addonname + "</addOnPackageName>";

		soapXML += "</sub:wsSubscribeAddOnByName>";
		soapXML += "</soap:Body>";
		soapXML += "</soap:Envelope>";
		return soapXML;
	}
	
	public static String getAccountStatement(String accountnumber,String fromdate,String todate) {
		String soapXML = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ver=\"http://crestelcaamprovider.elitecore.com/Version1\">";
		
		soapXML += "<soapenv:Header/>";
		soapXML += "<soapenv:Body>";
		soapXML += "<ver:getAccountStatement>";
		soapXML += "<arguments>";
		soapXML += "<accountNumber>" + accountnumber + "</accountNumber>";
		soapXML += "<fromDate>" + fromdate + "</fromDate>";
		soapXML +="<toDate>"+ todate +"</toDate>";
		soapXML +="</arguments>";

		soapXML += "</ver:getAccountStatement>";
		soapXML += "</soapenv:Body>";
		soapXML += "</soapenv:Envelope>";
		return soapXML;
	}

}
