package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class AddonSubscription implements Parcelable {
	
	//Addon Subscription pojo
	
	private String response = "";

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public AddonSubscription(Parcel in) {
		// TODO Auto-generated constructor stub
		readFromParcel(in);
	}

	public AddonSubscription() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {
		setResponse(in.readString());
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeString(response);
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public AddonSubscription createFromParcel(Parcel in) {
			return new AddonSubscription(in);
		}

		public AddonSubscription[] newArray(int size) {
			return new AddonSubscription[size];
		}
	};

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

}
