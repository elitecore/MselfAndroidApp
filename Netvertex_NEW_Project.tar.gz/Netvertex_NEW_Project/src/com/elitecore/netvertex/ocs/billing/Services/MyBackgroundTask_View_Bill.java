package com.elitecore.netvertex.ocs.billing.Services;

import java.net.Proxy;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.elitecore.netvertex.ocs.billing.OnTaskComplete;
import com.elitecore.netvertex.ocs.billing.pojo.GetviewbillKSOAP;

public class MyBackgroundTask_View_Bill extends
		AsyncTask<String, Integer, String> {

	//Asynctask for View Bill

	OnTaskComplete callBack;
	String response = null;
	private Context context;
	private ProgressDialog dialog;
	
	private String accountnumber;
	
	public static SoapSerializationEnvelope envelope;
	
	
	private String soapURLviewbill;
	private String soapactionviewbill;
	private String soapmethodnameviewbill;
	private String soapnamespaceviewbill;
	private HttpTransportSE androidHttpTransport;
	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	
	public MyBackgroundTask_View_Bill(Context context,String accountnumber,String soapURLviewbill,String soapactionviewbill,String soapmethodnameviewbill,String soapnamespaceviewbill,OnTaskComplete callback) {
		this.context = context;
		this.accountnumber=accountnumber;
		this.callBack=callback;
		this.soapURLviewbill=soapURLviewbill;
		this.soapactionviewbill=soapactionviewbill;
		this.soapmethodnameviewbill=soapmethodnameviewbill;
		this.soapnamespaceviewbill=soapnamespaceviewbill;
		
		
	}
	protected void onPreExecute() {
		dialog = ProgressDialog.show(context, "Processing", "Please Wait");
	}

	protected String doInBackground(String... strings) {
		
		try{
			androidHttpTransport = getHttpTransportSEviewbill();
			SoapObject request=new SoapObject(soapnamespaceviewbill, soapmethodnameviewbill);
			GetviewbillKSOAP getviewbill=new GetviewbillKSOAP();
			getviewbill.accountnumber=accountnumber;
			
			PropertyInfo pi= new PropertyInfo();
			pi.setName("arguments");
			pi.setValue(getviewbill);
			pi.setType(getviewbill.getClass());
			request.addProperty(pi);
			
			envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=false;
			envelope.setOutputSoapObject(request);
			System.out.println("Viewbill="+envelope.bodyOut);
			androidHttpTransport= getHttpTransportSEviewbill();
			androidHttpTransport.call(soapactionviewbill, envelope);
			System.out.println("Viewbill="+envelope.bodyIn);
		
		 		 
		 
		 	
			// Get the SoapResult from the envelope body.
			SoapObject resultRequestSOAP = (SoapObject) envelope.bodyIn;
			response = resultRequestSOAP.toString();

		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}

	
		
	protected void onPostExecute(String result) {
		if (dialog.isShowing()) {
			dialog.dismiss();
		}
		callBack.onGetBuildType(result);
	}

	
	private final HttpTransportSE getHttpTransportSEviewbill() {
		HttpTransportSE ht = new HttpTransportSE(Proxy.NO_PROXY, soapURLviewbill, 60000);
		ht.debug = true;
		ht.setXmlVersionTag("<!--?xml version=\"1.0\" encoding= \"UTF-8\" ?-->");
		return ht;
	}
}
	