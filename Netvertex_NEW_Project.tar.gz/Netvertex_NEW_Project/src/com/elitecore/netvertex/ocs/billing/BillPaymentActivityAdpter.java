package com.elitecore.netvertex.ocs.billing;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.Services.MyBackgroundTask_View_Bill;
import com.elitecore.netvertex.ocs.billing.Services.MyBackgroundTask_View_PDF;
import com.elitecore.netvertex.ocs.billing.constant.Constant;
import com.elitecore.netvertex.ocs.billing.pojo.GetViewBill;
import com.elitecore.netvertex.ocs.billing.pojo.GetViewBillList;
import com.elitecore.netvertex.ocs.billing.pojo.GetViewPDF;




public class BillPaymentActivityAdpter extends ArrayAdapter<GetViewBillList> implements OnTaskComplete {

	//Bill Payment Activity Adapter
	public static final int DIALOG_DOWNLOAD_PROGRESS = 0;
	 private ProgressDialog mProgressDialog;
	private List<GetViewBillList>viewbilllist;
	private int layoutResourceId;
	public Context context;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	SimpleDateFormat viewDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	public static String billnumber;
	public static String paymentbillnumber;
	public static Double paymentbillamount;
	public static Double billamount;
	private String billnumberpdf="";
	public static String paymenttype="";
	private String setbillpath="";
	public String getbillpath="";
	SharedPreferences pref;
	
	public BillPaymentActivityAdpter(Context context, int resource,List<GetViewBillList> viewbilllist) {
		super(context, resource, viewbilllist);
		this.context=context;
		this.layoutResourceId=resource;
	

	}

	
	//Create View and set value in controls
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		pref=context.getSharedPreferences(Constant.MyBillPDFpath, 0);
		final ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.transaction=(TextView)convertView.findViewById(R.id.txttransaction);
			viewHolder.billnumber = (TextView) convertView.findViewById(R.id.txtbillnumber);
			viewHolder.quickpay = (Button) convertView.findViewById(R.id.btnquickpay);
			viewHolder.amount = (TextView) convertView.findViewById(R.id.txtbillamount);
			viewHolder.billdate = (TextView) convertView.findViewById(R.id.txtbilldate);
			viewHolder.duedate = (TextView) convertView.findViewById(R.id.txtbillduedate);
			viewHolder.pdf = (Button) convertView.findViewById(R.id.btnbillpdf);
			
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		//Iterate value from GetViewBillList by it's position
		 final GetViewBillList currentviewbill = getItem(position);
		 billnumber=currentviewbill.getBillnumber();
		 paymentbillamount=currentviewbill.getAmount();
		 //Request forward to Bill Payment Gateway
		viewHolder.quickpay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				paymentbillnumber=currentviewbill.getBillnumber();
				billamount=currentviewbill.getAmount();
				paymentbillamount=currentviewbill.getAmount();
				
				Intent intent = new Intent(getContext(), PaymentGatewayBillPaymentActivity.class);
				getContext().startActivity(intent);
			}
		});
		viewHolder.pdf.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				billnumberpdf=currentviewbill.getBillnumber();
				MyBackgroundTask_View_PDF serviece = new MyBackgroundTask_View_PDF(context, billnumberpdf, Constant.SoapURLViewPDF, Constant.SoapActionViewPDF, Constant.Soap_METHOD_NAME_VIEWPDF, Constant.Soap_Namespace_ViewPDF,BillPaymentActivityAdpter.this);
				serviece.execute();
			}
		});
		
		if(currentviewbill.getBillstatus().equals("UNPAID")){
		if (convertView != null) {
			try{
				
				
				viewHolder.transaction.setText((position+1)+".");
			viewHolder.billnumber.setText(billnumber);
			
			viewHolder.amount.setText(String.valueOf(paymentbillamount/100));
			String viewbilldate,viewduedate;
			String getbilldate=currentviewbill.getBilldate();
			String getduedate=currentviewbill.getDuedate();
			viewbilldate=getbilldate.substring(0,getbilldate.indexOf("T"));
			viewduedate=getduedate.substring(0,getduedate.indexOf("T"));
			Date convertBillDate;
			Date convertDueDate;
			System.out.println(viewduedate);
			convertBillDate = viewDateFormat.parse(viewbilldate);
			convertDueDate = viewDateFormat.parse(viewduedate);
			System.out.println(convertDueDate);
			String billdate=simpleDateFormat.format(convertBillDate);
			String duedate=simpleDateFormat.format(convertDueDate);
			viewHolder.billdate.setText(billdate);
			viewHolder.duedate.setText(duedate);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		}
		return convertView;
	}
	

	public class ViewHolder {
		TextView transaction;
		TextView billnumber;
		TextView amount;
		TextView billdate;
		TextView duedate;
		Button quickpay;
		Button pdf;
	}


	@Override
	public void onGetBuildType(String result) {
		try {
			String responseviewpdf=result;
			MyBackgroundTask_View_PDF.envelope.dotNet = false;
			MyBackgroundTask_View_PDF.envelope.setOutputSoapObject(responseviewpdf);
			SoapObject resultRequestSOAP;
			resultRequestSOAP=(SoapObject)MyBackgroundTask_View_PDF.envelope.bodyIn;
			SoapObject fullpath = (SoapObject) resultRequestSOAP.getProperty(0);
			GetViewPDF viewpdf= new GetViewPDF();
			
			setbillpath=fullpath.getProperty("fullExportPath").toString();
			viewpdf.setPath(setbillpath);
			getbillpath=viewpdf.getPath();
			Editor editor;
			editor = pref.edit();
			editor.putString(Constant.PDFPath, getbillpath);
			editor.commit();
			Intent intent= new Intent(getContext(),BillPDFActvity.class);
		getContext().startActivity(intent);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}









