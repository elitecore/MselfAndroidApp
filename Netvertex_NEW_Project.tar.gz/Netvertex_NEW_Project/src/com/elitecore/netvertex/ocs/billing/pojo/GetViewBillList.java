package com.elitecore.netvertex.ocs.billing.pojo; 

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

public class GetViewBillList implements Parcelable {
	
	//Bill Payment pojo
	
	public static final long serialVersionUID = 1L;
	private String billnumber="";
	private Double amount;
	private String duedate="";
	private String billstatus="";
	
	
	public String getBillstatus() {
		return billstatus;
	}
	public void setBillstatus(String billstatus) {
		this.billstatus = billstatus;
	}
	public String getBillnumber() {
		return billnumber;
	}
	public void setBillnumber(String billnumber) {
		this.billnumber = billnumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getDuedate() {
		return duedate;
	}
	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}
	public String getBilldate() {
		return billdate;
	}
	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}

	private String billdate="";
	
	

		public GetViewBillList(Parcel in) {
		readFromParcel(in);
	}
		public GetViewBillList() {
			// TODO Auto-generated constructor stub
		}
	private void readFromParcel(Parcel in) {
		setBillnumber(in.readString());
		setAmount(in.readDouble());
		setDuedate(in.readString());
		setBilldate(in.readString());
		
	
	}

	
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(billnumber);
		dest.writeDouble(amount);
		dest.writeString(duedate);
		dest.writeString(billdate);
		
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetViewBillList createFromParcel(Parcel in) {
			return new GetViewBillList(in);
		}

		public GetViewBillList[] newArray(int size) {
			return new GetViewBillList[size];
		}
	};

	
}
