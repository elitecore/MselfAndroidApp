package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class AddonRecurringChargingList implements Parcelable {

	//Addon Recurring Charging List pojo
	
	protected Double recurringcharge;

	public Double getRecurringcharge() {
		return recurringcharge;
	}

	public void setRecurringcharge(Double recurringcharge) {
		this.recurringcharge = recurringcharge;
	}

	public AddonRecurringChargingList(Parcel in) {
		readFromParcel(in);
	}

	public AddonRecurringChargingList() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {
		setRecurringcharge(in.readDouble());

	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeDouble(recurringcharge);

	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public AddonRecurringChargingList createFromParcel(Parcel in) {
			return new AddonRecurringChargingList(in);
		}

		public AddonRecurringChargingList[] newArray(int size) {
			return new AddonRecurringChargingList[size];
		}
	};

	@Override
	public String toString() {
		return "" + recurringcharge + "";
	}

}
