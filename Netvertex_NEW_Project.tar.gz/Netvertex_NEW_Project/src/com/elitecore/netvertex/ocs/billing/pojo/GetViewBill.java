package com.elitecore.netvertex.ocs.billing.pojo; 

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

public class GetViewBill implements Parcelable {
	
	//Bill Payment pojo with Arrylist for multiple bill
	
	public static final long serialVersionUID = 1L;
	
	protected ArrayList<GetViewBillList>viewbilllist= new ArrayList<GetViewBillList>();
		public ArrayList<GetViewBillList> getViewbilllist() {
		return viewbilllist;
	}
	public void setViewbilllist(ArrayList<GetViewBillList> viewbilllist) {
		this.viewbilllist = viewbilllist;
	}
		public GetViewBill(Parcel in) {
		readFromParcel(in);
	}
		public GetViewBill() {
			// TODO Auto-generated constructor stub
		}
	private void readFromParcel(Parcel in) {
		
	
	}

	
	
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetViewBill createFromParcel(Parcel in) {
			return new GetViewBill(in);
		}

		public GetViewBill[] newArray(int size) {
			return new GetViewBill[size];
		}
	};

	
}
