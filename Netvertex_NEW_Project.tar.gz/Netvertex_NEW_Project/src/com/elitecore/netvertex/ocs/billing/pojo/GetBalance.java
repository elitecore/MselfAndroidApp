package com.elitecore.netvertex.ocs.billing.pojo;

import android.os.Parcel;
import android.os.Parcelable;

public class GetBalance implements Parcelable {
	//Balance List pojo
	public static final long serialVersionUID = 1L;
	protected Double totalusedbalance = 0.0;

	protected String package_name = "";
	protected Double usedbalance = 0.0;
	protected Long balance_type;
	private String validToDate;

	public String getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}

	private String validFromDate;
	private Double totalamt = 0.0;
	private Double usedamt = 0.0;
	private String servicealias = "";

	public String getServicealias() {
		return servicealias;
	}

	public void setServicealias(String servicealias) {
		this.servicealias = servicealias;
	}

	public Double getTotalamt() {
		return totalamt;
	}

	public void setTotalamt(Double totalamt) {
		this.totalamt = totalamt;
	}

	public Double getUsedamt() {
		return usedamt;
	}

	public void setUsedamt(Double usedamt) {
		this.usedamt = usedamt;
	}

	public Double getTotalusedbalance() {
		return totalusedbalance;
	}

	public void setTotalusedbalance(Double totalusedbalance) {
		this.totalusedbalance = totalusedbalance;
	}

	public Long getBalance_type() {
		return balance_type;
	}

	public void setBalance_type(Long balance_type) {
		this.balance_type = balance_type;
	}

	public GetBalance(Parcel in) {
		readFromParcel(in);
	}

	public GetBalance() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {
		setTotalusedbalance(in.readDouble());
		setPackage_name(in.readString());
		setUsedbalance(in.readDouble());
		setBalance_type(in.readLong());
		setTotalamt(in.readDouble());
		setUsedamt(in.readDouble());
	}

	public String getPackage_name() {
		return package_name;
	}

	public void setPackage_name(String package_name) {
		this.package_name = package_name;
	}

	public Double getUsedbalance() {
		return usedbalance;
	}

	public void setUsedbalance(Double usedbalance) {
		this.usedbalance = usedbalance;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeDouble(totalusedbalance);
		dest.writeString(package_name);
		dest.writeDouble(usedbalance);
		dest.writeLong(balance_type);
		dest.writeDouble(totalamt);
		dest.writeDouble(usedamt);
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetBalance createFromParcel(Parcel in) {
			return new GetBalance(in);
		}

		public GetBalance[] newArray(int size) {
			return new GetBalance[size];
		}
	};

	public String getValidToDate() {
		return validToDate;
	}

	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}

}
