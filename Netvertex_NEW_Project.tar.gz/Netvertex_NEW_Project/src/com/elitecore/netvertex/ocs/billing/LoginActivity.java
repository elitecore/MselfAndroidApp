package com.elitecore.netvertex.ocs.billing;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.Services.MyBackgroundTask;
import com.elitecore.netvertex.ocs.billing.XMLParse.LoginXMLParse;
import com.elitecore.netvertex.ocs.billing.constant.Constant;
import com.elitecore.netvertex.ocs.billing.constant.SoapXML;
import com.elitecore.netvertex.ocs.billing.pojo.SubscriberProfile;

public class LoginActivity extends Activity implements OnTaskComplete {

	private final Logger log = Logger.getLogger(this.getClass().getPackage()
			.getName());

	private EditText txtuname;
	private EditText txtpwd;
	private String username;
	private String password;
	SharedPreferences pref;
	private String uname;
	private String pwd;
	private SubscriberProfile profile;
	private Boolean isInternetPresent = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_loginactivity);
		pref = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		Button button = (Button) findViewById(R.id.btnlogin);
		txtuname = (EditText) findViewById(R.id.txtUsername);
		txtpwd = (EditText) findViewById(R.id.txtPassword);
		//Check Internet Connectivity
		isInternetPresent=isConnectingToInternet();
		if(isInternetPresent){
			//User Login
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
					if(txtuname.getText().toString().trim().equals("") || txtpwd.getText().toString().trim().equals("")){
						Toast toast = new Toast(getApplicationContext());
						LayoutInflater inflater = getLayoutInflater();
						View toastRoot = inflater.inflate(R.layout.toast_message_textview_blank,null);
						toast.setView(toastRoot);
						toast.setGravity(Gravity.BOTTOM, 10, 50);
						toast.setDuration(Toast.LENGTH_LONG);
						toast.show();
					}
					else{
						username = txtuname.getText().toString();
						password = txtpwd.getText().toString();
						String soapXML = SoapXML.getLoginString(username, password);
						MyBackgroundTask services = new MyBackgroundTask(
								LoginActivity.this, soapXML, Constant.SoapURL,
								Constant.SoapAction, LoginActivity.this);
						services.execute();
					}
				
				
			}
		});
		}
		else{
			Toast toast = new Toast(getApplicationContext());
			LayoutInflater inflater = getLayoutInflater();
			View toastRoot = inflater.inflate(R.layout.toast_message_no_internet_connectivity,
					null);
			toast.setView(toastRoot);
			toast.setGravity(Gravity.BOTTOM, 10, 50);
			toast.setDuration(Toast.LENGTH_LONG);
			toast.show();
			finish();
		}



	}
	//Callback Method
	@Override
	public void onGetBuildType(String result) {
		String response = result;
		try {
			BufferedReader br = new BufferedReader(new StringReader(response));
			InputSource isr = new InputSource(br);
			LoginXMLParse parse = new LoginXMLParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(parse);
			reader.parse(isr);
			profile = parse.subscriber;
			if (profile != null) {
				if (profile.getSubscriberIdentity() != null) {
					uname = profile.getSubscriberIdentity().toString();
					pwd = profile.getPassword().toString();
					log.log(Level.SEVERE, uname);
					String billingdate = profile.getBillingDate().toString();
					String customertype = profile.getCustomerType();
					String email = profile.getEmail();
					String subscribepackage = profile.getSubscriberPackage();
					String cui=profile.getCUI();
					String useraccountname=profile.getUsername();
					Editor editor;
					editor = pref.edit();
					editor.putBoolean("is_login", true);
					editor.putString(Constant.Login_User, uname);
					editor.putString(Constant.Login_User_pwd, pwd);
					editor.putString(Constant.Login_User_Billingdate,
							billingdate);
					editor.putString(Constant.Login_User_CustomerType,
							customertype);
					editor.putString(Constant.Login_User_Email, email);
					editor.putString(Constant.Login_User_Subscriberpackage,
							subscribepackage);
					editor.putString(Constant.Login_User_CUI, cui);
					editor.putString(Constant.Login_User_Name, useraccountname);
					editor.commit();
					Intent intent = new Intent(LoginActivity.this,
							com.elitecore.netvertex.ocs.billing.HomeActivity.class);
					startActivity(intent);
				} else {
					Toast toast = Toast.makeText(getApplicationContext(),
							"Username or Password is wrong", Toast.LENGTH_LONG);
					toast.setGravity(Gravity.CENTER, 0, 0);
					ImageView view = new ImageView(this);
					view.setImageResource(R.drawable.toast_message);
					toast.setView(view);
					toast.show();
				}
			} else {
				Toast toast = new Toast(getApplicationContext());
				LayoutInflater inflater = getLayoutInflater();
				View toastRoot = inflater.inflate(R.layout.toast_message_login,
						null);
				toast.setView(toastRoot);
				toast.setGravity(Gravity.BOTTOM, 10, 50);
				toast.setDuration(Toast.LENGTH_LONG);
				toast.show();
			}
		} catch (Exception e) {
			Log.e("SubscriberProfile", "Exception parse xml :" + e);
		}
	}
	
	//Check Internet Connectivity
	public boolean isConnectingToInternet() {
	      ConnectivityManager connectivity = (ConnectivityManager) getApplicationContext()
	            .getSystemService(Context.CONNECTIVITY_SERVICE);
	      if (connectivity != null) {
	         NetworkInfo[] info = connectivity.getAllNetworkInfo();
	         if (info != null)
	            for (int i = 0; i < info.length; i++)
	               if (info[i].getState() == NetworkInfo.State.CONNECTED) {
	                  return true;
	               }

	      }
	      return false;

	   }

}
