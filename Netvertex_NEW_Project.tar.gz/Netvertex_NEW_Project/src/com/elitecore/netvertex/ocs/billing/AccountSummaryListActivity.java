package com.elitecore.netvertex.ocs.billing;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.constant.Constant;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementCredit;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementDebit;
public class AccountSummaryListActivity extends ActionBarActivity {
	private TextView transaction;
	SharedPreferences pref;
	private String fromdate;
	private String todate;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	SimpleDateFormat viewDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private Date convertstartdate;
	private Date convertenddate;
	private String startdate,endate;
	private TextView credit_empty_text,debit_empty_text;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_account_summary_list);
		try{
			pref=getSharedPreferences(Constant.Transactiondate, MODE_PRIVATE);
			fromdate=pref.getString(Constant.Startdate, "");
			todate=pref.getString(Constant.Enddate, "");
			transaction=(TextView)findViewById(R.id.headertrasaction);
			credit_empty_text=(TextView)findViewById(R.id.txtemptytext_credit);
			debit_empty_text=(TextView)findViewById(R.id.txtemptytext_debit);
			convertstartdate=viewDateFormat.parse(fromdate);
			convertenddate=viewDateFormat.parse(todate);
			startdate=simpleDateFormat.format(convertstartdate);
			endate=simpleDateFormat.format(convertenddate);
			transaction.setText("Transaction Details"+"  "+"("+startdate+"  "+"TO"+"  "+endate+")");
			ArrayList<GetAccountStatementCredit> accountstatementcreditlist= AccountSummaryActivity.creditList;
			ArrayList<GetAccountStatementDebit> accountstatementdebitlist= AccountSummaryActivity.debitList;
			ListView accountcreditlist= (ListView)findViewById(R.id.lstaccountcreditsummary);
			ListView accountdebitlist= (ListView)findViewById(R.id.lstaccountdebitsummary);
			if(accountstatementcreditlist!= null){

				AccountStatementCreditActivityAdapter arp= new AccountStatementCreditActivityAdapter(this, R.layout.activity_account_statement_credit_list_adapter, accountstatementcreditlist);
				accountcreditlist.setAdapter(arp);
				credit_empty_text.setText("No Details Available");
				accountcreditlist.setEmptyView(credit_empty_text);


			}
			if(accountstatementdebitlist!=null){
				AccountSummaryDebitActivityAdapter arp1= new AccountSummaryDebitActivityAdapter(this, R.layout.activity_account_summary_debit_list_adapter, accountstatementdebitlist);
				accountdebitlist.setAdapter(arp1);
				debit_empty_text.setText("No Details Available");
				accountdebitlist.setEmptyView(debit_empty_text);
			}


		}
		catch(Exception e){
			e.printStackTrace();
		}

	}


}
