package com.elitecore.netvertex.ocs.billing;

import com.elitecore.netvertex.ocs.billing.constant.Constant;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class BillPDFActvity extends ActionBarActivity {
	private WebView browser;
	
	SharedPreferences pref;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill_pdfactvity);
		pref=getSharedPreferences(Constant.MyBillPDFpath, 0);
		String billpath=pref.getString(Constant.PDFPath, "");
		
		String pdffile=billpath.substring(73);
		System.out.println("PDFFile="+pdffile);
		
		
		browser = (WebView) findViewById(R.id.webView_bill);
		browser.setWebViewClient(new WebViewClient());
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		browser.getSettings().setBuiltInZoomControls(true);
		browser.getSettings().setSupportZoom(true);
		browser.getSettings().setLoadWithOverviewMode(true);
		browser.getSettings().setUseWideViewPort(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.getSettings().getLayoutAlgorithm();
		browser.getSettings().setDomStorageEnabled(true);
		
		 String pdfURL = "http://103.23.140.242:8586/bill/"+pdffile;
		browser.loadUrl("http://docs.google.com/gview?embedded=true&url="+pdfURL);
		      }
	
}
