package com.elitecore.netvertex.ocs.billing.pojo;
import java.util.Hashtable;

import org.ksoap2.serialization.KvmSerializable;
import org.ksoap2.serialization.PropertyInfo;


public class GetviewPDFKSOAP implements KvmSerializable{
	public String billnumber;
    
    
    
    
    public GetviewPDFKSOAP() {
		// TODO Auto-generated constructor stub
	} 
	public GetviewPDFKSOAP(String billnumber) {
		this.billnumber=billnumber;
	}
    
    
    public Object getProperty(int arg0) {
    	 switch(arg0)
         {
         case 0:
             return billnumber;
         
         }
         
         return null;
     }

	public int getPropertyCount() {
		// TODO Auto-generated method stub
		return 1;
	}

	public void getPropertyInfo(int index, Hashtable arg1, PropertyInfo info) {
		 switch(index)
	        {
	        case 0:
	            info.type = PropertyInfo.STRING_CLASS;
	            info.name = "billNumber";
	            break;
	           
	        default:break;
	        }
	    }

	 public void setProperty(int index, Object value) {
	        switch(index)
	        {
	        case 0:
	        	billnumber = value.toString();
	            break;
	        default:
	            break;
	        }
	    }
	 public String getInnerText() {
			// TODO Auto-generated method stub
			return null;
		}

		public void setInnerText(String arg0) {
			// TODO Auto-generated method stub
			
		}

}
