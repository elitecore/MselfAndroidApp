package com.elitecore.netvertex.ocs.billing;

//CallBack Method

public interface OnTaskComplete {
	 public void onGetBuildType(String result);
}
