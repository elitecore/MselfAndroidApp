
package com.elitecore.netvertex.ocs.billing.Services;

import java.net.Proxy;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.elitecore.netvertex.ocs.billing.BillPaymentActivityAdpter;
import com.elitecore.netvertex.ocs.billing.OnTaskComplete;
import com.elitecore.netvertex.ocs.billing.pojo.GetviewPDFKSOAP;

public class MyBackgroundTask_View_PDF extends
		AsyncTask<String, Integer, String> {

	//Asynctask for View Bill

	OnTaskComplete callBack;
	String response = null;
	private Context context;
	private ProgressDialog dialog;
	
	private String billnumber;
	
	public static SoapSerializationEnvelope envelope;
	
	
	private String soapURLviewpdf;
	private String soapactionviewpdf;
	private String soapmethodnameviewpdf;
	private String soapnamespaceviewpdf;
	private HttpTransportSE androidHttpTransport;
	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	
	public MyBackgroundTask_View_PDF(Context context,String billnumber,String soapURLviewpdf,String soapactionviewpdf,String soapmethodnameviewpdf,String soapnamespaceviewpdf,OnTaskComplete callback){
		this.context = context;
		this.billnumber=billnumber;
		this.callBack=callback;
		this.soapURLviewpdf=soapURLviewpdf;
		this.soapactionviewpdf=soapactionviewpdf;
		this.soapmethodnameviewpdf=soapmethodnameviewpdf;
		this.soapnamespaceviewpdf=soapnamespaceviewpdf;
		
		
	}
	protected void onPreExecute() {
		dialog = ProgressDialog.show(context, "Processing", "Please Wait");
	}

	protected String doInBackground(String... strings) {
		
		try{
			androidHttpTransport = getHttpTransportSEviewbill();
			SoapObject request=new SoapObject(soapnamespaceviewpdf, soapmethodnameviewpdf);
			GetviewPDFKSOAP getviewpdf=new GetviewPDFKSOAP();
			getviewpdf.billnumber=billnumber;
			
			PropertyInfo pi= new PropertyInfo();
			pi.setName("arguments");
			pi.setValue(getviewpdf);
			pi.setType(getviewpdf.getClass());
			request.addProperty(pi);
			
			envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
			envelope.dotNet=false;
			envelope.setOutputSoapObject(request);
			System.out.println("Viewpdf="+envelope.bodyOut);
			androidHttpTransport= getHttpTransportSEviewbill();
			androidHttpTransport.call(soapactionviewpdf, envelope);
			System.out.println("Viewpdf="+envelope.bodyIn);
		
		 		 
		 
		 	
			// Get the SoapResult from the envelope body.
			SoapObject resultRequestSOAP = (SoapObject) envelope.bodyIn;
			response = resultRequestSOAP.toString();

		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}

	
		
	protected void onPostExecute(String result) {
		if (dialog.isShowing()) {
			dialog.dismiss();
		}
		callBack.onGetBuildType(result);
	}

	
	private final HttpTransportSE getHttpTransportSEviewbill() {
		HttpTransportSE ht = new HttpTransportSE(Proxy.NO_PROXY, soapURLviewpdf, 60000);
		ht.debug = true;
		ht.setXmlVersionTag("<!--?xml version=\"1.0\" encoding= \"UTF-8\" ?-->");
		return ht;
	}
}
	