package com.elitecore.netvertex.ocs.billing.XMLParse;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex.ocs.billing.pojo.SubscriberProfile;

public class LoginXMLParse extends DefaultHandler {

	//Login User response parser
	
	public SubscriberProfile subscriber = null;

	StringBuilder builder;
	

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();

		if (localName.equals("Envelope")) {

		} else if (localName.equals("Body")) {

		} else if (localName.equals("wsAuthenticateResponse")) {

		} else if (localName.equals("return")) {

		} else if (localName.equals("responseCode")) {

		} else if (localName.equals("responseMessage")) {

		} else if (localName.equals("subscriberProfile")) {
			subscriber = new SubscriberProfile();
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.equalsIgnoreCase("arpu")) {
			subscriber.setARPU(Long.parseLong(builder.toString()));
		} else if (localName.equalsIgnoreCase("billingDate")) {
			subscriber.setBillingDate(Long.parseLong(builder.toString()));
		} else if (localName.equalsIgnoreCase("cui")) {
			subscriber.setCUI(builder.toString());
		} else if (localName.equalsIgnoreCase("email")) {
			subscriber.setEmail(builder.toString());
		} else if (localName.equalsIgnoreCase("encryptionType")) {
			subscriber.setEncryptionType(Long.parseLong(builder.toString()));
		} else if (localName.equalsIgnoreCase("imsi")) {
			subscriber.setIMSI(builder.toString());
		} else if (localName.equalsIgnoreCase("password")) {
			subscriber.setPassword(builder.toString());
		} else if (localName.equalsIgnoreCase("subscriberID")) {
			subscriber.setSubscriberIdentity(builder.toString());
		} else if (localName.equalsIgnoreCase("userName")) {
			subscriber.setUsername(builder.toString());
		}
		else if (localName.equalsIgnoreCase("customerType")) {
			subscriber.setCustomerType(builder.toString());
		}
		else if (localName.equalsIgnoreCase("subscriberPackage")) {
			subscriber.setSubscriberPackage(builder.toString());
		}
		

	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}