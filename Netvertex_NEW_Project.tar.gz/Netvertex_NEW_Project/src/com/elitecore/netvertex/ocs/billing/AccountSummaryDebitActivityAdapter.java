package com.elitecore.netvertex.ocs.billing;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.pojo.GetAccountStatementDebit;
public class AccountSummaryDebitActivityAdapter extends ArrayAdapter<GetAccountStatementDebit> {

	//AccountSummaryActivity Debit List Array Adpter
	
	private List<GetAccountStatementDebit> accountdebitsummary;
	private int layoutResourceId;
	private Context context;
	View view;
	Double amount;
	String date;
	String description;

	public AccountSummaryDebitActivityAdapter(Context context, int resource,
			List<GetAccountStatementDebit> accountdebitstatement) {
		super(context, resource, accountdebitstatement);
		this.context = context;
		this.accountdebitsummary = accountdebitstatement;
		this.layoutResourceId = resource;

	}
	//Create View and set value in controls
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.transaction=(TextView)convertView.findViewById(R.id.txttransaction);
			viewHolder.amount = (TextView) convertView
					.findViewById(R.id.txtamount);
			viewHolder.date = (TextView) convertView.findViewById(R.id.txtdate);
			viewHolder.description = (TextView) convertView
					.findViewById(R.id.txtdescription);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		//Value set in (GetAccountStatementDebit) Pojo and iterate by it's position
		final GetAccountStatementDebit currentaccountdebitstatement = getItem(position);
		if (convertView != null) {
			amount = currentaccountdebitstatement.getAmount()/100;
			date = currentaccountdebitstatement.getTransactiondate();
			description = currentaccountdebitstatement.getCategory();
			

			viewHolder.transaction.setText((position+1)+".");
			viewHolder.amount.setText(String.valueOf(amount)+"  "+currentaccountdebitstatement.getCurreny());
			viewHolder.date.setText(String.valueOf(date));
			viewHolder.description.setText(String.valueOf(description)+"  "+currentaccountdebitstatement.getTransactiontype());
		}
		return convertView;
	}

	public class ViewHolder {
		TextView transaction;
		TextView amount;
		TextView date;
		TextView description;
	}
}
