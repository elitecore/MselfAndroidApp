package com.elitecore.netvertex.ocs.billing;

import java.util.ArrayList;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;

import com.elitecore.netvertex.ocs.billing.HomeActivity;
import com.elitecore.netvertex.ocs.billing.R;
import com.elitecore.netvertex.ocs.billing.pojo.GetBalance;

public class BalanceActivity extends ActionBarActivity {
	//Plan wise balance display
	private ArrayList<GetBalance> gbl;
	private TextView emptytext;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		ArrayList<GetBalance> baltype2 = new ArrayList<GetBalance>();
		ArrayList<GetBalance> baltype4 = new ArrayList<GetBalance>();
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_balance_display);
		gbl = HomeActivity.balanceList;
		GetBalance gb;
		emptytext = (TextView) findViewById(R.id.txtemptytext);
		for (int i = 0; i < gbl.size(); i++) {
			gb = gbl.get(i);

			if (gb.getBalance_type() == 2) {
				baltype2.add(gb);
			}

			else if (gb.getBalance_type() == 4) {
				baltype4.add(gb);
			}
			ListView lst = (ListView) findViewById(R.id.listView1);
			ListView lst2 = (ListView) findViewById(R.id.listView4);
			if (baltype2 != null) {
				BalanceActivityAdpter adp = new BalanceActivityAdpter(
						this, R.layout.activity_balance_display_adpter,
						baltype2);
				lst.setAdapter(adp);
				emptytext.setText("No Plan Subscribe");
				lst.setEmptyView(emptytext);
			}
			if (baltype4 != null) {
				BalanceActivityAdpter adp = new BalanceActivityAdpter(
						this, R.layout.activity_balance_display1_adpter,
						baltype4);
				lst2.setAdapter(adp);
			}
		}
	}
}
