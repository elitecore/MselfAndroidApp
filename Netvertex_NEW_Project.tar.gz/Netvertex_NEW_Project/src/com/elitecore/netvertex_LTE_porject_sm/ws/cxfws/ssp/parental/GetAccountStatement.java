package com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental; 

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

public class GetAccountStatement implements Parcelable {
	public static final long serialVersionUID = 1L;
	
	protected ArrayList<GetAccountStatementCredit> accountcreditlist= new ArrayList<GetAccountStatementCredit>();
	protected ArrayList<GetAccountStatementDebit> accountdebitlist= new ArrayList<GetAccountStatementDebit>();
	protected Double totalamount=0.0;

		public GetAccountStatement(Parcel in) {
		readFromParcel(in);
	}
		public GetAccountStatement() {
			// TODO Auto-generated constructor stub
		}
	private void readFromParcel(Parcel in) {
		
		setTotalamount(in.readDouble());
	}

	
	public ArrayList<GetAccountStatementCredit> getAccountcreditlist() {
		return accountcreditlist;
	}
	public void setAccountcreditlist(
			ArrayList<GetAccountStatementCredit> accountcreditlist) {
		this.accountcreditlist = accountcreditlist;
	}
	public ArrayList<GetAccountStatementDebit> getAccountdebitlist() {
		return accountdebitlist;
	}
	public void setAccountdebitlist(
			ArrayList<GetAccountStatementDebit> accountdebitlist) {
		this.accountdebitlist = accountdebitlist;
	}
	public Double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(Double totalamount) {
		this.totalamount = totalamount;
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeDouble(totalamount);
		
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public GetAccountStatement createFromParcel(Parcel in) {
			return new GetAccountStatement(in);
		}

		public GetAccountStatement[] newArray(int size) {
			return new GetAccountStatement[size];
		}
	};

	
}
