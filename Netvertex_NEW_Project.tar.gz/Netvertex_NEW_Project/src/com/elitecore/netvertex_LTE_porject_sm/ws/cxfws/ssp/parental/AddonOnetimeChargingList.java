package com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental;

import android.os.Parcel;
import android.os.Parcelable;

public class AddonOnetimeChargingList implements Parcelable {

	protected Double ontimecharge;

	public AddonOnetimeChargingList(Parcel in) {
		readFromParcel(in);
	}

	public AddonOnetimeChargingList() {
		// TODO Auto-generated constructor stub
	}

	private void readFromParcel(Parcel in) {
		setontimecharge(in.readDouble());

	}

	public Double getontimecharge() {
		return ontimecharge;
	}

	public void setontimecharge(Double ontimecharge) {
		this.ontimecharge = ontimecharge;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeDouble(ontimecharge);

	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public AddonOnetimeChargingList createFromParcel(Parcel in) {
			return new AddonOnetimeChargingList(in);
		}

		public AddonOnetimeChargingList[] newArray(int size) {
			return new AddonOnetimeChargingList[size];
		}
	};

	@Override
	public String toString() {
		return "" + ontimecharge + "";
	}

}
