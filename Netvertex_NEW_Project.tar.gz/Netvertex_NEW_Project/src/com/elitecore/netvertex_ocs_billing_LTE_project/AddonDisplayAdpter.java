package com.elitecore.netvertex_ocs_billing_LTE_project;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.AddonOnetimeChargingList;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.AddonRecurringChargingList;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetBalance;

public class AddonDisplayAdpter extends ArrayAdapter<AddonList> {
	private List<AddonList> addon;
	private int layoutResourceId;
	private Context context;
	GetBalance currentservice;
	public static String addonStr;
	public static Double totalcharge;

	View view;
	SharedPreferences preference;
	SharedPreferences pref;
	

	
	public AddonDisplayAdpter(Context context, int resource,
			List<AddonList> addonsubs) {
		super(context, resource, addonsubs);
		this.context = context;
		this.addon = addonsubs;
		this.layoutResourceId = resource;
		
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.addonname = (TextView) convertView
					.findViewById(R.id.txtaddon);
			viewHolder.addonbuy = (Button) convertView
					.findViewById(R.id.btnaddon);
			viewHolder.addondescription = (TextView) convertView
					.findViewById(R.id.txtdescription);
			viewHolder.addononetimechargeprice = (TextView) convertView
					.findViewById(R.id.txtonetimecharge);
			viewHolder.addonrecurringchargeprice = (TextView) convertView
					.findViewById(R.id.txtrecurringcharge);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		final AddonList currentaddon = getItem(position);
		final AddonList addonbuy = addon.get(position);

		viewHolder.addonbuy.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				addonStr = addonbuy.getProdcatname();
				totalcharge = Double
						.parseDouble((String) viewHolder.addononetimechargeprice
								.getText())
						+ Double.parseDouble((String) viewHolder.addonrecurringchargeprice
								.getText());
				Intent intent = new Intent(getContext(), PaymentGateway.class);
				getContext().startActivity(intent);
			}
		});

		if (convertView != null) {
			viewHolder.addonname.setText(currentaddon.getProdcatname()
					.toString());
			viewHolder.addondescription.setText(currentaddon.getDiscription());
			long ontimechargeprice = 0;
			long recurringchargeprice = 0;
			for (AddonOnetimeChargingList addonOnetimeChargingList : currentaddon
					.getAddonOnetimeChargingList()) {
				ontimechargeprice += addonOnetimeChargingList.getontimecharge();
			}

			for (AddonRecurringChargingList addonrecurringcharinglist : currentaddon
					.getAddonrecuuringcharinglist()) {
				recurringchargeprice += addonrecurringcharinglist
						.getRecurringcharge();
			}
			viewHolder.addononetimechargeprice.setText(String
					.valueOf(ontimechargeprice / 100));
			viewHolder.addonrecurringchargeprice.setText(String
					.valueOf(recurringchargeprice / 100));
		}
		return convertView;
	}

	public class ViewHolder {
		TextView addonname;
		TextView addondescription;
		TextView addononetimechargeprice;
		TextView addonrecurringchargeprice;
		Button addonbuy;
	}

	}
