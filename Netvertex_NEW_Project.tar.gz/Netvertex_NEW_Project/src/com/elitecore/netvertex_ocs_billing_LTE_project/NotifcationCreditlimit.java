package com.elitecore.netvertex_ocs_billing_LTE_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class NotifcationCreditlimit extends ActionBarActivity {
	private SeekBar seekbar1;
	private TextView txtseekbarprogress;
	private Button btnnotificationset;
	private CheckBox chkbox;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_notifcation_creditlimit);

		seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
		txtseekbarprogress = (TextView) findViewById(R.id.txtseekprogress);
		btnnotificationset = (Button) findViewById(R.id.btnnotificationset);
		chkbox = (CheckBox) findViewById(R.id.chckbox1);
		// chkbox.setChecked(true);
		chkbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {

				// TODO Auto-generated method stub

				if (chkbox.isChecked() == true) {

					txtseekbarprogress.setEnabled(false);
					seekbar1.setEnabled(false);
					btnnotificationset.setEnabled(false);
				} else {

					txtseekbarprogress.setEnabled(true);
					seekbar1.setEnabled(true);

					btnnotificationset.setEnabled(true);
				}

			}
		});

		btnnotificationset.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Toast toast = new Toast(getApplicationContext());

				LayoutInflater inflater = getLayoutInflater();
				View toastRoot = inflater.inflate(
						R.layout.toast_message_notification_success, null);

				toast.setView(toastRoot);
				toast.setGravity(Gravity.BOTTOM, 10, 50);
				toast.setDuration(Toast.LENGTH_LONG);
				toast.show();
				Intent intent = new Intent(NotifcationCreditlimit.this,
						HomeActivity.class);
				startActivity(intent);

			}
		});

		seekbar1.setMax(100);
		seekbar1.setProgress(0);
		seekbar1.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			int prg = 0;

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {

				// TODO Auto-generated method stub
				prg = progress;
				txtseekbarprogress.setText(Integer.toString(prg) + "%");

			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub

			}
		});
	}

}
