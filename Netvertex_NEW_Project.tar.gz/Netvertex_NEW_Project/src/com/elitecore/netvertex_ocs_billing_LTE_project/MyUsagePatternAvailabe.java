package com.elitecore.netvertex_ocs_billing_LTE_project;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.elitecore.netvertex_ocs_billing_LTE_project.constant.Constant;

public class MyUsagePatternAvailabe extends ActionBarActivity {
	private WebView browser;
	SharedPreferences pref;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_my_usage_pattern_availabe);
		//pref = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		//String url = String.format(getResources().getString(R.string.url),pref.getString(Constant.Login_User, ""));
		String username="MT541987";
		String url = String.format(getResources().getString(R.string.url),username);
		
		browser = (WebView) findViewById(R.id.webView1);
		browser.setWebViewClient(new WebViewClient());
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		browser.getSettings().setBuiltInZoomControls(true);
		browser.getSettings().setSupportZoom(true);
		browser.getSettings().setLoadWithOverviewMode(true);
		browser.getSettings().setUseWideViewPort(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.getSettings().getLayoutAlgorithm();
		browser.getSettings().setDomStorageEnabled(true);
		browser.loadUrl(url);
	}
}
