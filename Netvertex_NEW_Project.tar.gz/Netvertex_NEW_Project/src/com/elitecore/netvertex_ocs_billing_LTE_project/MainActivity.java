package com.elitecore.netvertex_ocs_billing_LTE_project;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.elitecore.netvertex_ocs_billing_LTE_project.constant.Constant;

public class MainActivity extends Activity {
	private long DELAY = 3000;
	private boolean scheduled = false;
	private Timer splashTimer;
	SharedPreferences pref;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		
		
		
		splashTimer = new Timer();

		splashTimer.schedule(new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				pref = getSharedPreferences(Constant.MyLoginPREFERENCES,
						MODE_PRIVATE);
				MainActivity.this.finish();
				if (pref.contains(Constant.Login_User)
						&& pref.contains(Constant.Login_User_pwd)) {

					startActivity(new Intent(MainActivity.this,
							HomeActivity.class));
				} else {
					startActivity(new Intent(MainActivity.this,
							Loginactivity.class));
				}
			}
		}, DELAY);
		 }
		
	
		
	
	

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (scheduled)
			splashTimer.cancel();
		splashTimer.purge();
	}
	
	 
}
