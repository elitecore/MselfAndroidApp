package com.elitecore.netvertex_ocs_billing_LTE_project;

import java.util.ArrayList;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.TextView;

import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatementCredit;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatementDebit;
import com.elitecore.netvertex_ocs_billing_LTE_project.Services.MyBackgroundTask_Billing;
import com.elitecore.netvertex_ocs_billing_LTE_project.constant.Constant;
public class AccountSummaryList extends ActionBarActivity {
	private TextView transaction;
	SharedPreferences pref;
	public String startdate;
	public String enddate;
//	private Button pdf;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_account_summary_list);
		pref=getSharedPreferences(Constant.Transactiondate, MODE_PRIVATE);
		startdate=pref.getString(Constant.Startdate, "");
		enddate=pref.getString(Constant.Enddate, "");
//		pdf=(Button)findViewById(R.id.btnpdf);
		transaction=(TextView)findViewById(R.id.headertrasaction);
		transaction.setText("Transaction Details"+"  "+"("+startdate+"  "+"TO"+"  "+enddate+")");
		
	
		
		
		ArrayList<GetAccountStatementCredit> accountstatementcreditlist= AccountSummary.creditList;
		ArrayList<GetAccountStatementDebit> accountstatementdebitlist= AccountSummary.debitList;
		ListView accountcreditlist= (ListView)findViewById(R.id.lstaccountcreditsummary);
		ListView accountdebitlist= (ListView)findViewById(R.id.lstaccountdebitsummary);
		if(accountstatementcreditlist!= null){
			
			AccountStatementCreditListAdapter arp= new AccountStatementCreditListAdapter(this, R.layout.activity_account_statement_credit_list_adapter, accountstatementcreditlist);
			accountcreditlist.setAdapter(arp);
			
			
		}
		if(accountstatementdebitlist!=null){
			AccountSummaryDebitListAdapter arp1= new AccountSummaryDebitListAdapter(this, R.layout.activity_account_summary_debit_list_adapter, accountstatementdebitlist);
			accountdebitlist.setAdapter(arp1);
		}
		
		
//		pdf.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View v) {
//				
//			}
//		});

	}

	
}
