package com.elitecore.netvertex_ocs_billing_LTE_project;

public interface OnTaskComplete {
	 public void onGetBuildType(String result);
}
