package com.elitecore.netvertex_ocs_billing_LTE_project.constant;

public class Constant {
	
	// webservice URL and action for authentication
	//public static final String SoapURL="http://192.168.2.22:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapURL="http://103.23.140.242:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapAction="http://192.168.2.22:8586/sm/services/ParentalService?wsdl";
	//public static final String SoapAction="http://103.23.140.242:8586/sm/services/ParentalService?wsdl";
	public static final String SoapAction="http://103.23.140.242:8586/sm64622/services/ParentalService?wsdl";
	public static final String SoapURLaddonsubs="http://103.23.140.242:8586/sm64622/services/SubscriptionService?wsdl";
	public static final String SoapURL="http://103.23.140.242:8586/sm64622/services/ParentalService?wsdl";
	public static final String SoapActionaddonsubs="http://103.23.140.242:8586/sm64622/services/SubscriptionService?wsdl";
	public static final String SoapURLOCS="http://103.23.140.239:8992/Integrations/IntegrationWebService?wsdl";
	public static final String SoapActionOCS="http://103.23.140.239:8992/Integrations/IntegrationWebService?wsdl";
	public static final String SoapURLPLM="http://103.23.140.239:8992/ProductManagerAPIWebService?wsdl";
	public static final String SoapActionPLM="http://103.23.140.239:8992/ProductManagerAPIWebService?wsdl";
	public static final String SoapURLbiiling="http://10.110.1.145:9070/cresteldunning/service/CrestelDunningManagerService/CrestelDunningManager?wsdl";
	public static final String SoapActionbiiling="http://10.110.1.145:9070/cresteldunning/service/CrestelDunningManagerService/CrestelDunningManager?wsdl";
	public static final String SoapActionBilling = "/";
	public static final String SoapMETHOD_NAMEBilling = "getAccountStatement";
	public static final String SoapNAMESPACEBilling= "http://crestelcaamprovider.elitecore.com/Version1";
	public static final String SoapURLBilling = "http://103.23.140.242:9080/crestelcaam/AccountOperationsWebService/CrestelCAAMAccountOperationService/CrestelCAAMAccountOperation?wsdl";
	public static final String BillDesk="https://www.billdesk.com/pgidsk/pgijsp/MerchantPaymentoption.jsp";
	
	
	public static final String Login_User = "login_user";
	public static final String Login_User_pwd = "login_user_pwd";
	public static final String Login_User_Billingdate = "login_user_billingdate";
	public static final String Login_User_CustomerType = "login_user_customertype";
	public static final String Login_User_Email = "login_user_email";
	public static final String Login_User_Subscriberpackage="login_user_subscriberpackage";
	public static final String Login_User_CUI="login_user_cui";
	public static final String MyLoginPREFERENCES = "MyPrefs";
	public static final String MyServicealias = "MySeriveAlias";
	public static final String Service_alias = "ServiceAlias";
	public static final String Transactiondate = "MySeriveAlias";
	public static final String Startdate = "start_date";
	public static final String Enddate = "end_date";
}
