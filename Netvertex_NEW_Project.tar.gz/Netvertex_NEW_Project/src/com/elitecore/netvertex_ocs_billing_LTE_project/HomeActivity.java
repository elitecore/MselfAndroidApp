package com.elitecore.netvertex_ocs_billing_LTE_project;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.media.audiofx.Visualizer.MeasurementPeakRms;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetBalance;
import com.elitecore.netvertex_ocs_billing_LTE_project.Services.MyBackgroundTask;
import com.elitecore.netvertex_ocs_billing_LTE_project.XMLParse.AddonListParser;
import com.elitecore.netvertex_ocs_billing_LTE_project.XMLParse.GetBalanceParse;
import com.elitecore.netvertex_ocs_billing_LTE_project.constant.Constant;
import com.elitecore.netvertex_ocs_billing_LTE_project.constant.SoapXML;

public class HomeActivity extends Activity implements OnTaskComplete {

	private TextView t1;
	SharedPreferences preference;
	private String subscriberidentity;
	private Button buttonlogout;
	private Button buttongetbal;
	private Button buttonaddonsubscription;
	public static ArrayList<GetBalance> balanceList;

	public static ArrayList<AddonList> addonsublist;
	public static ArrayList<GetActiveAddon> activeaddonlist;
	private ProgressDialog pBar;
	private String currentCall;
	private Button btnmyprofile;
	private Button btnmyusagepattern;
	private String servicealias;
	SharedPreferences pref;
	private Boolean isInternetPresent = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_home);
		
		t1 = (TextView) findViewById(R.id.uname);
		buttonlogout = (Button) findViewById(R.id.btnlogout);
		preference = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		pref = getSharedPreferences(Constant.MyServicealias, MODE_PRIVATE);
		String username = preference.getString(Constant.Login_User, "");
		subscriberidentity = preference.getString(Constant.Login_User, "");
		t1.setText("Welcome " + username + " !!");
		t1.setGravity(Gravity.BOTTOM);
		isInternetPresent=isConnectingToInternet();
		currentCall = "AutoGetBal";
		String getbalxml = SoapXML.getbalance(subscriberidentity);
		MyBackgroundTask services = new MyBackgroundTask(HomeActivity.this,
				getbalxml, Constant.SoapURLOCS, Constant.SoapActionOCS,
				HomeActivity.this);
		services.execute();
		if(isInternetPresent){
		buttonlogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Editor editor = preference.edit();
				editor.clear();
				editor.commit();
				moveTaskToBack(true);
				HomeActivity.this.finish();
				Intent i = new Intent(HomeActivity.this, Loginactivity.class);
				i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(i);
			}
		});

		buttongetbal = (Button) findViewById(R.id.btngetbalance);
		buttongetbal.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				currentCall = "GetBal";
				String getbalxml = SoapXML.getbalance(subscriberidentity);
				MyBackgroundTask services = new MyBackgroundTask(
						HomeActivity.this, getbalxml, Constant.SoapURLOCS,
						Constant.SoapActionOCS, HomeActivity.this);
				services.execute();
			
				
			}
		});
		buttonaddonsubscription = (Button) findViewById(R.id.btnsubscription);
		buttonaddonsubscription.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				currentCall = "AddSub";
				if (currentCall.equals("AddSub")) {
					String addonsubsxml = SoapXML.getaddonsubscription();
					MyBackgroundTask services = new MyBackgroundTask(
							HomeActivity.this, addonsubsxml,
							Constant.SoapURLPLM, Constant.SoapActionPLM,
							HomeActivity.this);
					services.execute();
				}
				
				
			}
		});
		
			Button btnaddonunsubscription = (Button) findViewById(R.id.btnunsubscription);
			btnaddonunsubscription.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(HomeActivity.this,AccountSummary.class);
				startActivity(intent);
				
			}
		});
		btnmyprofile = (Button) findViewById(R.id.btnmyprofile);
		btnmyprofile.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(HomeActivity.this, MyProfile.class);
				startActivity(intent);
				
				
			}
		});

		btnmyusagepattern = (Button) findViewById(R.id.btnmypatteren);
		btnmyusagepattern.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(HomeActivity.this,
						MyUsagePatternAvailabe.class);
				startActivity(intent);
				}
				
			
			
		});
		
		
		}
		else{
			Toast toast = new Toast(getApplicationContext());
			LayoutInflater inflater = getLayoutInflater();
			View toastRoot = inflater.inflate(R.layout.toast_message_no_internet_connectivity,
					null);
			toast.setView(toastRoot);
			toast.setGravity(Gravity.BOTTOM, 10, 50);
			toast.setDuration(Toast.LENGTH_LONG);
			toast.show();
			finish();
		}

	}

	@Override
	public void onBackPressed() {
		try {
			pBar.dismiss(); // may be NullPointer

		} catch (Exception e) {
		}
		super.onBackPressed();
	}

	@Override
	public void onGetBuildType(String result) {
		if (currentCall.equals("GetBal"))
			callGetBal(result);
		if (currentCall.equals("AddSub"))
			callAddOnSubscriber(result);
		if (currentCall.equals("AutoGetBal"))
			autoGetBal(result);
	}

	private void autoGetBal(String result) {
		String response1 = result;
		try {
			BufferedReader br = new BufferedReader(new StringReader(response1));
			InputSource isr = new InputSource(br);
			GetBalanceParse getBalanceParser = new GetBalanceParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(getBalanceParser);
			reader.parse(isr);
			balanceList = (ArrayList<GetBalance>) getBalanceParser.listbal;
			activeaddonlist = (ArrayList<GetActiveAddon>) getBalanceParser.addonunsubslist;
			if (activeaddonlist != null && !activeaddonlist.isEmpty()) {
				for (GetActiveAddon activeaddon : activeaddonlist) {
					servicealias = activeaddon.getServicealias();
					System.out.println("Servicealias=" + servicealias);
					
				}
				Editor editor;
				editor = pref.edit();
				editor.putString(Constant.Service_alias,servicealias);
				editor.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void callAddOnSubscriber(String result) {
		String response2 = result;

		try {
			BufferedReader br = new BufferedReader(new StringReader(response2));
			InputSource isr = new InputSource(br);
			AddonListParser addonsubsparser = new AddonListParser();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(addonsubsparser);
			reader.parse(isr);
			addonsublist = (ArrayList<AddonList>) addonsubsparser.addonlist;
			Intent intent = new Intent(HomeActivity.this, AddonDisplay.class);
			startActivity(intent);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void callGetBal(String result) {
		String response1 = result;
		try {
			BufferedReader br = new BufferedReader(new StringReader(response1));
			InputSource isr = new InputSource(br);
			GetBalanceParse getBalanceParser = new GetBalanceParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(getBalanceParser);
			reader.parse(isr);
			balanceList = (ArrayList<GetBalance>) getBalanceParser.listbal;
			activeaddonlist = (ArrayList<GetActiveAddon>) getBalanceParser.addonunsubslist;
			
			Intent intent = new Intent(HomeActivity.this, BalanceDisplay.class);
			startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        MenuInflater inflater = getMenuInflater();
	        inflater.inflate(R.menu.menu, menu);
	        ActionBar actionbar= getActionBar();
			actionbar.setDisplayHomeAsUpEnabled(true);
			   return true;
	    }
	  @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	 
	        super.onOptionsItemSelected(item);
	 
	        switch(item.getItemId()){
	          
	            
	            case R.id.monthlybalance:
	            	Toast.makeText(this, "Coming Soon",Toast.LENGTH_SHORT).show();
	                break;
	            case R.id.notification:
	            	Toast.makeText(this, "Coming Soon",Toast.LENGTH_SHORT).show();
	                break;
	        }
	        return true;
	     
	 
	    }
	  public boolean isConnectingToInternet() {
	      ConnectivityManager connectivity = (ConnectivityManager) getApplicationContext()
	            .getSystemService(Context.CONNECTIVITY_SERVICE);
	      if (connectivity != null) {
	         NetworkInfo[] info = connectivity.getAllNetworkInfo();
	         if (info != null)
	            for (int i = 0; i < info.length; i++)
	               if (info[i].getState() == NetworkInfo.State.CONNECTED) {
	                  return true;
	               }

	      }
	      return false;

	   }

       
	}

