package com.elitecore.netvertex_ocs_billing_LTE_project.Services;

import java.net.Proxy;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.GetaccountstatementKSOAP;
import com.elitecore.netvertex_ocs_billing_LTE_project.OnTaskComplete;

public class MyBackgroundTask_Billing extends
		AsyncTask<String, Integer, String> {

	

	OnTaskComplete callBack;
	String response = null;
	private Context context;
	private ProgressDialog dialog;
	
	private String accountnumber;
	private String startdate;
	private String enddate;
	public static SoapSerializationEnvelope envelope;
	private String soapURLbilling;
	private String soapactionbilling;
	private String soapmethodnamebilling;
	private String soapnamespacebilling;
	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public MyBackgroundTask_Billing(Context context,String accountnumber,String startdate,String enddate,String SoapURLBilling,String SoapActionBilling,String SoapNamespaceBilling,String SoapMethodnameBilling,OnTaskComplete callback) {
		this.context = context;
		this.accountnumber=accountnumber;
		this.startdate=startdate;
		this.enddate=enddate;
		this.callBack=callback;
		this.soapURLbilling=SoapURLBilling;
		this.soapactionbilling=SoapActionBilling;
		this.soapmethodnamebilling=SoapMethodnameBilling;
		this.soapnamespacebilling=SoapNamespaceBilling;
	}

	protected void onPreExecute() {
		dialog = ProgressDialog.show(context, "Processing", "Please Wait");
	}

	protected String doInBackground(String... strings) {
		HttpTransportSE androidHttpTransport = getHttpTransportSE();
		try {
			/* Get what user typed to the EditText. */
			SoapObject request = new SoapObject(soapnamespacebilling, soapmethodnamebilling);
			GetaccountstatementKSOAP accountstatement = new GetaccountstatementKSOAP();
//			accountstatement.accountnumber = "ELITE543436";
			accountstatement.accountnumber = accountnumber;
			accountstatement.fromdate = startdate;
			accountstatement.enddate = enddate;

			PropertyInfo pi = new PropertyInfo();
			pi.setName("arguments");
			pi.setValue(accountstatement);
			pi.setType(accountstatement.getClass());
			request.addProperty(pi);

			envelope = new SoapSerializationEnvelope(
					SoapEnvelope.VER11);
			envelope.dotNet = false;
			envelope.setOutputSoapObject(request);
			// Make the soap call.
			System.out.println("MyBackgroundTask_Billing.doInBackground()"
					+ envelope.bodyOut);
			androidHttpTransport = getHttpTransportSE();
			androidHttpTransport.call(soapactionbilling, envelope);
			System.out.println("MyBackgroundTask_Billing.doInBackground()"
					+ envelope.bodyIn);
			// Get the SoapResult from the envelope body.
			SoapObject resultRequestSOAP = (SoapObject) envelope.bodyIn;
			response = resultRequestSOAP.toString();

			
		} catch (Exception aE) {
			aE.printStackTrace();
		}
		return response;
	}

	protected void onPostExecute(String result) {
		if (dialog.isShowing()) {
			dialog.dismiss();
		}
		callBack.onGetBuildType(result);
	}

	private final HttpTransportSE getHttpTransportSE() {
		HttpTransportSE ht = new HttpTransportSE(Proxy.NO_PROXY, soapURLbilling, 60000);
		ht.debug = true;
		ht.setXmlVersionTag("<!--?xml version=\"1.0\" encoding= \"UTF-8\" ?-->");
		return ht;
	}

}
