package com.elitecore.netvertex_ocs_billing_LTE_project.XMLParse;
/*package com.elitecore.netvertex_LTE_project.XMLParse;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatement;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatementCredit;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatementDebit;

public class GetAccountParse extends DefaultHandler {

	public GetAccountStatement accountstatement = null;
	public GetAccountStatementCredit credit=null;
	public GetAccountStatementDebit debit=null;

	public static List<GetAccountStatement> accountstatementlist = new ArrayList<GetAccountStatement>();

	StringBuilder builder;
	Boolean istotalclosingbalance=false;
	Boolean iscrdit = false;
	Boolean isdebit = false;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();
		if (qName.equals("return")) {
			accountstatement = new GetAccountStatement();
		}

		if (qName.equals("creditDocumentVO")) {
			credit = new GetAccountStatementCredit();
			iscrdit = true;
		}
		if (qName.equals("debitDocumentVO")) {
			debit = new GetAccountStatementDebit();
			isdebit = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (qName.equals("totalClosingBalance")) {
			accountstatement.setTotalamount(Double.parseDouble(builder.toString()));
		}

		if (qName.equals("creditDocumentVO")) {
			iscrdit = false;
			accountstatement.getAccountcreditlist().add(credit);
		}

		if (iscrdit) {
			if (qName.equalsIgnoreCase("amount")) {
				credit.setAmount(Double.parseDouble(builder
						.toString()));
			} else if (qName.equalsIgnoreCase("currency")) {
				credit.setCurrency(builder.toString());
			} else if (qName.equalsIgnoreCase("documentCategory")) {
				credit.setCategory(builder.toString());
			} else if(qName.equals("documentType")){
				credit.setTransactiontype(builder.toString());
			}else if(qName.equals("documentnumber")){
				credit.setReceipt((builder.toString()));

			}else if(qName.equals("postDate")){
				credit.setTransactiondate(simpleDateFormat.format(new Date(Long.parseLong(builder.toString()))));	
			}
		}

		if (qName.equals("debitDocumentVO")) {
			isdebit = false;
			accountstatement.getAccountdebitlist().add(debit);
		}

		if (isdebit) {
			if (qName.equalsIgnoreCase("amount")) {
				credit.setAmount(Double.parseDouble(builder
						.toString()));
			} else if (qName.equalsIgnoreCase("currency")) {
				credit.setCurrency(builder.toString());
			} else if (qName.equalsIgnoreCase("documentCategory")) {
				credit.setCategory(builder.toString());
			} else if(qName.equals("documentType")){
				credit.setTransactiontype(builder.toString());
			}
			else if(qName.equals("documentnumber")){
				credit.setReceipt(builder.toString());

			}
			else if(qName.equals("postDate")){
				credit.setTransactiondate(simpleDateFormat.format(new Date(Long.parseLong(builder.toString()))));
			}
		}

	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
*/