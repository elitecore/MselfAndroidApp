package com.elitecore.netvertex_ocs_billing_LTE_project.XMLParse;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AddonUnSubscriptionParser extends DefaultHandler {
	StringBuilder builder;

	public String responseMessage;

	@Override
	public void startDocument() throws SAXException {
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		builder = new StringBuilder();
		if (localName.equals("responseMessage")) {
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (localName.equalsIgnoreCase("responseMessage")) {
			responseMessage = builder.toString();
		}
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
