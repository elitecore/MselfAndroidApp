package com.elitecore.netvertex_ocs_billing_LTE_project.XMLParse;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental.AddonSubscription;

public class AddonSubscriptionParser extends DefaultHandler {

	StringBuilder builder;

	public AddonSubscription addsubs = null;

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();

		if (localName.equals("responseMessage")) {
			addsubs = new AddonSubscription();

		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.equalsIgnoreCase("responseMessage")) {

			addsubs.setResponse(builder.toString());
		}
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
