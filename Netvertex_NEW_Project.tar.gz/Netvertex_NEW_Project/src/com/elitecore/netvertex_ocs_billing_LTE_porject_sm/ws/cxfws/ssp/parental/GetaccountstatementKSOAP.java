package com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental;
import java.util.Hashtable;

import org.ksoap2.serialization.KvmSerializable;
import org.ksoap2.serialization.PropertyInfo;


public class GetaccountstatementKSOAP implements KvmSerializable{
	public String accountnumber;
    public String fromdate;
    public String enddate;
    
	
    
    
    
    public GetaccountstatementKSOAP() {
		// TODO Auto-generated constructor stub
	} 
	public GetaccountstatementKSOAP(String accountnumber,String fromdate ,String todate) {
		this.accountnumber=accountnumber;
		this.fromdate=fromdate;
		this.enddate=todate;
	}
    
    
    public Object getProperty(int arg0) {
    	 switch(arg0)
         {
         case 0:
             return accountnumber;
         case 1:
             return fromdate; 
         case 2:
        	 return enddate;
         }
         
         return null;
     }

	public int getPropertyCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	public void getPropertyInfo(int index, Hashtable arg1, PropertyInfo info) {
		 switch(index)
	        {
	        case 0:
	            info.type = PropertyInfo.STRING_CLASS;
	            info.name = "accountNumber";
	            break;
	        case 1:
	            info.type = PropertyInfo.STRING_CLASS;
	            info.name = "fromDate";
	            break;
	        case 2:
	            info.type = PropertyInfo.STRING_CLASS;
	            info.name = "toDate";
	            break;
	        default:break;
	        }
	    }

	 public void setProperty(int index, Object value) {
	        switch(index)
	        {
	        case 0:
	        	accountnumber = value.toString();
	            break;
	        case 1:
	        	fromdate = value.toString();
	            break;
	        case 2:
	        	enddate = value.toString();
	            break;
	        
	        default:
	            break;
	        }
	    }
	 public String getInnerText() {
			// TODO Auto-generated method stub
			return null;
		}

		public void setInnerText(String arg0) {
			// TODO Auto-generated method stub
			
		}

}
