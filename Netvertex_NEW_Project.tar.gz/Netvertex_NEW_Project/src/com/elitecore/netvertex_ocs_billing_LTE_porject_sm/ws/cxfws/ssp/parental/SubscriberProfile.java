package com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SubscriberProfile implements Serializable {
	public static final long serialVersionUID = 1L;
	protected String Username;
	protected String Password;
	protected String SubscriberIdentity;
	protected String SubscriberPackage;
	protected String SubscriberStatus;
	protected String IMSI;
	protected String MSISDN;
	protected String MAC;
	protected String MEID;
	protected String IMEI;
	protected String EUI64;
	protected String Modified_EUI64;
	protected String ESN;
	protected String CUI;
	protected Long ARPU;
	protected String ParentID;
	protected String GroupName;
	protected Long EncryptionType;
	protected String CustomerType;
	protected Long BillingDate;
	protected Long ExpiryDate;
	protected String Email;
	protected String Phone;
	protected String SIPURL;
	protected String Area;
	protected String City;
	protected String Zone;
	protected String Country;
	protected Long Birthday;
	protected Map<String, Long> usageMap;

	public SubscriberProfile() {
		usageMap = new HashMap<String, Long>();
	}

	public void addSubcriberUsage(String packageName, Long usage) {
		usageMap.put(packageName, usage);
	}

	public Map<String, Long> getUsageMap() {
		return usageMap;
	}

	public void setUsageMap(Map<String, Long> usageMap) {
		usageMap = usageMap;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getZone() {
		return Zone;
	}

	public void setZone(String zone) {
		Zone = zone;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getSubscriberIdentity() {
		return SubscriberIdentity;
	}

	public void setSubscriberIdentity(String subscriberIdentity) {
		SubscriberIdentity = subscriberIdentity;
	}

	public String getSubscriberPackage() {
		return SubscriberPackage;
	}

	public void setSubscriberPackage(String subscriberPackage) {
		SubscriberPackage = subscriberPackage;
	}

	public String getSubscriberStatus() {
		return SubscriberStatus;
	}

	public void setSubscriberStatus(String subscriberStatus) {
		SubscriberStatus = subscriberStatus;
	}

	public String getIMSI() {
		return IMSI;
	}

	public void setIMSI(String iMSI) {
		IMSI = iMSI;
	}

	public String getMSISDN() {
		return MSISDN;
	}

	public void setMSISDN(String mSISDN) {
		MSISDN = mSISDN;
	}

	public String getMAC() {
		return MAC;
	}

	public void setMAC(String mAC) {
		MAC = mAC;
	}

	public String getMEID() {
		return MEID;
	}

	public void setMEID(String mEID) {
		MEID = mEID;
	}

	public String getIMEI() {
		return IMEI;
	}

	public void setIMEI(String iMEI) {
		IMEI = iMEI;
	}

	public String getEUI64() {
		return EUI64;
	}

	public void setEUI64(String eUI64) {
		EUI64 = eUI64;
	}

	public String getModified_EUI64() {
		return Modified_EUI64;
	}

	public void setModified_EUI64(String modified_EUI64) {
		Modified_EUI64 = modified_EUI64;
	}

	public String getESN() {
		return ESN;
	}

	public void setESN(String eSN) {
		ESN = eSN;
	}

	public String getCUI() {
		return CUI;
	}

	public void setCUI(String cUI) {
		CUI = cUI;
	}

	public Long getARPU() {
		return ARPU;
	}

	public void setARPU(Long aRPU) {
		ARPU = aRPU;
	}

	public String getParentID() {
		return ParentID;
	}

	public void setParentID(String parentID) {
		ParentID = parentID;
	}

	public String getGroupName() {
		return GroupName;
	}

	public void setGroupName(String groupName) {
		GroupName = groupName;
	}

	public Long getEncryptionType() {
		return EncryptionType;
	}

	public void setEncryptionType(Long EncryptionType) {
		EncryptionType = EncryptionType;
	}

	public String getCustomerType() {
		return CustomerType;
	}

	public void setCustomerType(String customerType) {
		CustomerType = customerType;
	}

	public Long getBillingDate() {
		return BillingDate;
	}

	public void setBillingDate(Long billingDate) {
		BillingDate = billingDate;
	}

	public Long getExpiryDate() {
		return ExpiryDate;
	}

	public void setExpiryDate(Long expiryDate) {
		ExpiryDate = expiryDate;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	public String getSIPURL() {
		return SIPURL;
	}

	public void setSIPURL(String sIPURL) {
		SIPURL = sIPURL;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public Long getBirthday() {
		return Birthday;
	}

	public void setBirthday(Long birthday) {
		Birthday = birthday;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public String getCompany() {
		return Company;
	}

	public void setCompany(String company) {
		Company = company;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getDeviceType() {
		return DeviceType;
	}

	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}

	public String getFAP() {
		return FAP;
	}

	public void setFAP(String fAP) {
		FAP = fAP;
	}

	public String getCadre() {
		return Cadre;
	}

	public void setCadre(String cadre) {
		Cadre = cadre;
	}

	public String getPARAM1() {
		return PARAM1;
	}

	public void setPARAM1(String pARAM1) {
		PARAM1 = pARAM1;
	}

	public String getPARAM2() {
		return PARAM2;
	}

	public void setPARAM2(String pARAM2) {
		PARAM2 = pARAM2;
	}

	public String getPARAM3() {
		return PARAM3;
	}

	public void setPARAM3(String pARAM3) {
		PARAM3 = pARAM3;
	}

	public String getPARAM4() {
		return PARAM4;
	}

	public void setPARAM4(String pARAM4) {
		PARAM4 = pARAM4;
	}

	public String getPARAM5() {
		return PARAM5;
	}

	public void setPARAM5(String pARAM5) {
		PARAM5 = pARAM5;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	protected String Role;
	protected String Company;
	protected String Department;
	protected String DeviceType;
	protected String FAP;
	protected String Cadre;
	protected String PARAM1;
	protected String PARAM2;
	protected String PARAM3;
	protected String PARAM4;
	protected String PARAM5;
	protected String Status;

}
