package com.elitecore.netvertex_ocs_billing_LTE_porject_sm.ws.cxfws.ssp.parental;

import java.util.ArrayList;

import android.os.Parcel;
import android.os.Parcelable;

public class AddonList implements Parcelable {

	protected String prodcatname = "";
	protected String discription = "";
	protected ArrayList<AddonOnetimeChargingList> addonOnetimeChargingList = new ArrayList<AddonOnetimeChargingList>();
	protected ArrayList<AddonRecurringChargingList> addonrecuuringcharinglist = new ArrayList<AddonRecurringChargingList>();

	public ArrayList<AddonRecurringChargingList> getAddonrecuuringcharinglist() {
		return addonrecuuringcharinglist;
	}

	public void setAddonrecuuringcharinglist(
			ArrayList<AddonRecurringChargingList> addonrecuuringcharinglist) {
		this.addonrecuuringcharinglist = addonrecuuringcharinglist;
	}

	public ArrayList<AddonOnetimeChargingList> getAddonOnetimeChargingList() {
		return this.addonOnetimeChargingList;
	}

	public void setAddonOnetimeChargingList(
			ArrayList<AddonOnetimeChargingList> addonOnetimeChargingList) {
		this.addonOnetimeChargingList = addonOnetimeChargingList;
	}

	public AddonList(Parcel in) {
		readFromParcel(in);
	}

	public AddonList() {
		// addonOnetimeChargingList = new ArrayList<AddonOnetimeChargingList>();
	}

	private void readFromParcel(Parcel in) {
		setProdcatname(in.readString());
		setDiscription(in.readString());

	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getProdcatname() {
		return prodcatname;
	}

	public void setProdcatname(String prodcatname) {
		this.prodcatname = prodcatname;
	}

	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {

		dest.writeString(prodcatname);
		dest.writeString(discription);
	}

	public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
		public AddonList createFromParcel(Parcel in) {
			return new AddonList(in);
		}

		public AddonList[] newArray(int size) {
			return new AddonList[size];
		}
	};

}
