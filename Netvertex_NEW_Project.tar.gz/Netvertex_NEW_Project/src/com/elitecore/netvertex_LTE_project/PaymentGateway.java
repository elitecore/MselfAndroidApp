package com.elitecore.netvertex_LTE_project;

import org.apache.http.util.EncodingUtils;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.billdesk.pgidsk.PGIUtil;
import com.elitecore.netvertex_LTE_project.constant.Constant;

public class PaymentGateway extends ActionBarActivity {

	public static String postdata;
	SharedPreferences preference,pref;
	private String strSALTKEY;
	String username;
	WebView webView;
	String servicealias;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_payment_gateway);

		preference = getSharedPreferences(Constant.MyLoginPREFERENCES, 0);
		username = preference.getString(Constant.Login_User, "");
		pref = getSharedPreferences(Constant.MyServicealias,0);
		servicealias=pref.getString(Constant.Service_alias, "");
		System.out.println("Services="+servicealias);
		
		
		webView = (WebView) findViewById(R.id.webView2);

		strSALTKEY = "e4QeKCM3RJID";

		String msgstring = "IDEAWIFI|"
				+ username
				+ "|NA|"
				+ AddonDisplayAdpter.totalcharge
				+ "|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/?addonname="
				+ AddonDisplayAdpter.addonStr +':' +servicealias +':'+username + "";
		System.out.println("MessageString=" + msgstring);
		String checkSum = PGIUtil.doDigest(msgstring, strSALTKEY);
		System.out.println("Checksum" + checkSum);
		postdata = "msg=IDEAWIFI|"
				+ username
				+ "|NA|"
				+ AddonDisplayAdpter.totalcharge
				+ "|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://103.23.140.242:8586/index/?addonname="
				+ AddonDisplayAdpter.addonStr + ':' +servicealias +':'+ username + "|"
				+ checkSum + "";
		System.out.println(postdata);

		webView.postUrl("https://www.billdesk.com/pgidsk/PGIMerchantPayment",
				EncodingUtils.getBytes(postdata, "BASE64"));
		webView.setWebViewClient(new WebViewClient() {

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub

				return false;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				// TODO Auto-generated method stub

			}

		}

		);

		webView.getSettings().setLoadsImagesAutomatically(true);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webView.getSettings().setBuiltInZoomControls(true);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setLoadWithOverviewMode(true);
		webView.getSettings().setUseWideViewPort(true);
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		webView.getSettings().getLayoutAlgorithm();
		webView.getSettings().setDomStorageEnabled(true);

	}

}
