package com.elitecore.netvertex_LTE_project.XMLParse;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.AddonOnetimeChargingList;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.AddonRecurringChargingList;

public class AddonListParser extends DefaultHandler {

	public AddonList addon = null;
	public AddonOnetimeChargingList addononetimecharging = null;
	public AddonRecurringChargingList addonrecurringcharging = null;
	public List<AddonList> addonlist = new ArrayList<AddonList>();
	public List<AddonOnetimeChargingList> addonlistonetimecharging = new ArrayList<AddonOnetimeChargingList>();
	public List<AddonRecurringChargingList> addonlistrecurringcharging = new ArrayList<AddonRecurringChargingList>();
	StringBuilder builder;

	Boolean isaddon = false;
	Boolean isaddonetimeoncharge = false;
	Boolean isaddonrecurringcharge = false;

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();
		if (qName.equals("return")) {
			addon = new AddonList();
		}
		if (qName.equals("productSpecification")) {
			isaddon = true;
		}
		if (qName.equals("oneTimeCharge")) {
			addononetimecharging = new AddonOnetimeChargingList();
			isaddonetimeoncharge = true;
		}
		if (qName.equals("recurringCharge")) {
			addonrecurringcharging = new AddonRecurringChargingList();
			isaddonrecurringcharge = true;
		}

	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (qName.equals("productSpecification")) {
			isaddon = false;
			addonlist.add(addon);

		}
		if (isaddon) {
			if (qName.equals("productName")) {
				addon.setProdcatname(builder.toString());
			}
			if (qName.equals("description")) {
				addon.setDiscription(builder.toString());
			}

		}
		if (qName.equalsIgnoreCase("resultAttributeValues")) {
			if (isaddonetimeoncharge) {
				if (!builder.toString().trim().equalsIgnoreCase("")) {
					addononetimecharging.setontimecharge(Double
							.parseDouble(builder.toString()));
				}
			}
			if (isaddonrecurringcharge) {
				if (!builder.toString().trim().equalsIgnoreCase("")) {
					addonrecurringcharging.setRecurringcharge(Double
							.parseDouble(builder.toString()));
				}
			}

		}
		if (qName.equals("oneTimeCharge")) {
			isaddonetimeoncharge = false;
			addon.getAddonOnetimeChargingList().add(addononetimecharging);
		}
		if (qName.equals("recurringCharge")) {
			isaddonrecurringcharge = false;
			addon.getAddonrecuuringcharinglist().add(addonrecurringcharging);

		}
	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
