package com.elitecore.netvertex_LTE_project.XMLParse;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetActiveAddon;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetBalance;

public class GetBalanceParse extends DefaultHandler {

	public GetBalance balance = null;
	public GetActiveAddon addonunsubs = null;

	public List<GetBalance> listbal = new ArrayList<GetBalance>();
	public List<GetActiveAddon> addonunsubslist = new ArrayList<GetActiveAddon>();

	// Stack<String> stack = new Stack<String>();
	StringBuilder builder;
	String packageName;
	long usage;
	Integer type = 2;
	private Double total_amt;
	private Double used_amt;
	private String service_aliase;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	Boolean isbalance = false;
	Boolean isaddonunsubs = false;

	@Override
	public void startDocument() throws SAXException {

	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {

		builder = new StringBuilder();

		if (qName.equals("balanceData")) {
			balance = new GetBalance();
			isbalance = true;
		}
		if (qName.equals("packageData")) {
			addonunsubs = new GetActiveAddon();
			isaddonunsubs = true;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (qName.equals("balanceData")) {
			isbalance = false;
			balance.setTotalamt(total_amt);
			balance.setUsedamt(used_amt);
			listbal.add(balance);
			if (balance.getBalance_type() == 4) {
				total_amt = balance.getTotalusedbalance();
				used_amt = balance.getUsedbalance();
			}
		}

		if (isbalance) {
			if (qName.equalsIgnoreCase("totalUsageValue")) {
				balance.setTotalusedbalance(Double.parseDouble(builder
						.toString()));
			} else if (qName.equalsIgnoreCase("packageName")) {
				balance.setPackage_name(builder.toString());
			} else if (qName.equalsIgnoreCase("usedValue")) {
				balance.setUsedbalance(Double.parseDouble(builder.toString()));
			} else if (qName.equalsIgnoreCase("balanceTypeId")) {
				balance.setBalance_type(Long.parseLong(builder.toString()));
			} else if (qName.equalsIgnoreCase("serviceAlias")) {
				balance.setServicealias((builder.toString()));
			} else if (qName.equalsIgnoreCase("validToDate")) {
				balance.setValidToDate(simpleDateFormat.format(new Date(Long
						.parseLong(builder.toString()))));
			} else if (qName.equalsIgnoreCase("validFromDate")) {
				balance.setValidFromDate(simpleDateFormat.format(new Date(Long
						.parseLong(builder.toString()))));
			}
		}

		if (qName.equals("packageData")) {
			isaddonunsubs = false;
			addonunsubs.setService_alias_set(service_aliase);
			addonunsubslist.add(addonunsubs);
			if (addonunsubs.getPriority() == 1) {

				service_aliase = addonunsubs.getServicealias();
			}

		}

		if (isaddonunsubs) {
			if (qName.equalsIgnoreCase("packageName")) {
				addonunsubs.setPackage_name(builder.toString());

			} else if (qName.equalsIgnoreCase("priority")) {
				addonunsubs.setPriority(Integer.parseInt(builder.toString()));

			} else if (qName.equalsIgnoreCase("serviceAlias")) {
				addonunsubs.setServicealias(builder.toString());

			} else if (qName.equalsIgnoreCase("validToDate")) {

				addonunsubs.setValidToDate(simpleDateFormat.format(new Date(
						Long.parseLong(builder.toString()))));

			} else if (qName.equalsIgnoreCase("validFromDate")) {
				addonunsubs.setValidFromDate(simpleDateFormat.format(new Date(
						Long.parseLong(builder.toString()))));
			}

		}

	}

	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {

		String tempString = new String(ch, start, length);
		builder.append(tempString);
	}

}
