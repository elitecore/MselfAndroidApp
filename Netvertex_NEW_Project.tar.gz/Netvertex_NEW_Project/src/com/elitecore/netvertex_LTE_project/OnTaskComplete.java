package com.elitecore.netvertex_LTE_project;

public interface OnTaskComplete {
	 public void onGetBuildType(String result);
}
