package com.elitecore.netvertex_LTE_project;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetBalance;

public class BalanceDisplayArrayadpter extends ArrayAdapter<GetBalance> {

	public static List<GetBalance> balance;
	private int layoutResourceId;
	public Context context;

	public BalanceDisplayArrayadpter(Context context, int resource,
			List<GetBalance> bal) {
		super(context, resource, bal);
		this.layoutResourceId = resource;
		this.context = context;

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);

			viewHolder = new ViewHolder();

			viewHolder.pName = (TextView) convertView
					.findViewById(R.id.txtpackname);
			viewHolder.progressbal = (ProgressBar) convertView
					.findViewById(R.id.progressavlabal);
			viewHolder.avalbal = (TextView) convertView
					.findViewById(R.id.txtavlabal);
			viewHolder.usedbal = (TextView) convertView
					.findViewById(R.id.txtusedbal);
			viewHolder.expirydate = (TextView) convertView
					.findViewById(R.id.txtexpdate);
			viewHolder.startdate = (TextView) convertView
					.findViewById(R.id.txtstartdate);
			viewHolder.bal = (TextView) convertView
					.findViewById(R.id.txtbalance);
			viewHolder.expdatebal = (TextView) convertView
					.findViewById(R.id.txtexpdatebalance);
			viewHolder.startdatebal = (TextView) convertView
					.findViewById(R.id.txtstartdatebalance);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		GetBalance currentbal = getItem(position);

		if (currentbal.getBalance_type() == 2) {

			if (convertView != null) {

				viewHolder.pName.setText(currentbal.getPackage_name()
						.toString());
				double usedbal = currentbal.getUsedbalance();
				long MB = 1024 * 1024;
				int usedbalance = (int) (usedbal / MB);
				double avlbal = currentbal.getTotalusedbalance();
				long avalaiblebalance = (long) (avlbal / MB);
				viewHolder.avalbal.setText(String.valueOf(avalaiblebalance)
						+ "MB");
				viewHolder.progressbal.setMax((int) avalaiblebalance);
				viewHolder.progressbal.setProgress(usedbalance);
				long progress = viewHolder.progressbal.getProgress();
				viewHolder.usedbal.setText(String.valueOf(progress) + "MB");
				viewHolder.expirydate.setText(currentbal.getValidToDate());
				viewHolder.startdate.setText(currentbal.getValidFromDate());
			}
		}

		if (currentbal.getBalance_type() == 4) {
			if (convertView != null) {
				double usedbalance=currentbal.getUsedbalance()/100;
				double totalbalance=currentbal.getTotalusedbalance()/100;
				
				viewHolder.bal.setText(String.valueOf(usedbalance+"/"+totalbalance+" BHT"));
				viewHolder.expdatebal.setText(currentbal.getValidToDate());
				viewHolder.startdatebal.setText(currentbal.getValidFromDate());
			}
		}
		return convertView;
	}

	private class ViewHolder {
		TextView pName;
		ProgressBar progressbal;
		TextView usedbal;
		TextView expirydate;
		TextView avalbal;
		TextView bal;
		TextView expdatebal;
		TextView startdatebal;
		TextView startdate;
	}
}
