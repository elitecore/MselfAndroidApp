package com.elitecore.netvertex_LTE_project;

import java.util.List;

import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.AddonList;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatement;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatementCredit;


import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class AccountSummaryListAdapter extends ArrayAdapter<GetAccountStatement> {

	private List<GetAccountStatement> accountsummary;
	private int layoutResourceId;
	private Context context;
	View view;
	Double amount;
	String date;
	String description;
	public AccountSummaryListAdapter(Context context, int resource,List<GetAccountStatement> accountstatement) {
		super(context, resource,accountstatement);
		this.context = context;
		this.accountsummary = accountstatement;
		this.layoutResourceId = resource;
		
	}
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder viewHolder;
		if (convertView == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			convertView = inflater.inflate(layoutResourceId, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.amount=(TextView)convertView.findViewById(R.id.txtamount);
			viewHolder.date=(TextView)convertView.findViewById(R.id.txtdate);
			viewHolder.description=(TextView)convertView.findViewById(R.id.txtdescription);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		
		final GetAccountStatement currentaccountstatement = getItem(position);
		
		if (convertView != null) {
			for(GetAccountStatementCredit accountstatementcredtilist : currentaccountstatement.getAccountcreditlist()){
				amount+=accountstatementcredtilist.getAmount();
				date+=accountstatementcredtilist.getTransactiondate();
				description+=accountstatementcredtilist.getCategory();
			}
			viewHolder.amount.setText(String.valueOf(amount));
			viewHolder.date.setText(String.valueOf(date));
			viewHolder.description.setText(String.valueOf(description));
			
				}
		return convertView;
	}
	
	public class ViewHolder {
		TextView amount;
		TextView date;
		TextView description;
	}
}


