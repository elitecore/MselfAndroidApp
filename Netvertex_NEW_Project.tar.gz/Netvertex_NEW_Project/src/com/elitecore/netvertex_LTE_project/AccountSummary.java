package com.elitecore.netvertex_LTE_project;

import java.io.BufferedReader;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.ksoap2.transport.*;
import com.elitecore.netvertex_LTE_porject_sm.ws.cxfws.ssp.parental.GetAccountStatement;
import com.elitecore.netvertex_LTE_project.Services.MyBackgroundTask;
import com.elitecore.netvertex_LTE_project.XMLParse.GetAccountParse;
import com.elitecore.netvertex_LTE_project.XMLParse.LoginXMLParse;
import com.elitecore.netvertex_LTE_project.constant.Constant;
import com.elitecore.netvertex_LTE_project.constant.SoapXML;

import android.support.v7.app.ActionBarActivity;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

@SuppressLint("SimpleDateFormat")
public class AccountSummary extends ActionBarActivity implements OnTaskComplete{


	private EditText fromdate;
	private EditText todate;
	private Button buttonfromdate;
	private Button buttontodate;
	private String startdate;
	private String enddate;
	private Button submit;
	private String accountnum;
	
	private static final String SOAP_ACTION = "http://192.168.2.3:9080/crestelcaam/AccountOperationsWebService/CrestelCAAMAccountOperationService/CrestelCAAMAccountOperation?wsdl";
	private static final String METHOD_NAME = "ver";
	private static final String NAMESPACE = "";
	private static final String URL = "http://192.168.2.3:9080/crestelcaam/AccountOperationsWebService/CrestelCAAMAccountOperationService/CrestelCAAMAccountOperation?wsdl";
	private SoapObject resultRequestSOAP = null;
	public static ArrayList<GetAccountStatement> accountdisplaylist;
	
	SharedPreferences pref;
	final Calendar myCalendar = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_account_summary);
		//button_account_summary=(Button)findViewById(R.id.btnaccountsummary);
		fromdate=(EditText)findViewById(R.id.datepickedfromdate);
		todate=(EditText)findViewById(R.id.datepickedtodate);

		buttonfromdate=(Button)findViewById(R.id.btnfromdate);
		buttontodate=(Button)findViewById(R.id.btntodate);
		pref = getSharedPreferences(Constant.MyLoginPREFERENCES, MODE_PRIVATE);
		//accountnum=pref.getString(Constant.Login_User_CUI, "");
		
		final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				myCalendar.set(Calendar.YEAR, year);
				myCalendar.set(Calendar.MONTH, monthOfYear);
				myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
				updateLabel();


			}

		};
		final DatePickerDialog.OnDateSetListener datedialog = new DatePickerDialog.OnDateSetListener() {

			@Override
			public void onDateSet(DatePicker view, int year, int monthOfYear,
					int dayOfMonth) {
				// TODO Auto-generated method stub
				myCalendar.set(Calendar.YEAR, year);
				myCalendar.set(Calendar.MONTH, monthOfYear);
				myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
				updateLabeltodate();



			}

		};

		buttonfromdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				new DatePickerDialog(AccountSummary.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
						myCalendar.get(Calendar.DAY_OF_MONTH)).show();
			}
		});
		buttontodate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				new DatePickerDialog(AccountSummary.this, datedialog, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
						myCalendar.get(Calendar.DAY_OF_MONTH)).show();

			}
		});
		submit=(Button)findViewById(R.id.btnsubmit);
		submit.setOnClickListener(new OnClickListener() {

			

				@Override
				public void onClick(View v) {  
					HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
				try {
                    /* Get what user typed to the EditText. */
                    String startdate = fromdate.getText().toString();
                    String enddate= todate.getText().toString();
                    SoapObject request = new SoapObject(NAMESPACE,
                           METHOD_NAME);
                    // Add the input required by web service
                    request.addProperty("accountNumber",accountnum);
                    request.addProperty("fromDate", startdate);
                    request.addProperty("toDate",enddate);
                    
                    SoapSerializationEnvelope envelope =new SoapSerializationEnvelope(SoapEnvelope.VER11);
                    envelope.setOutputSoapObject(request);
                    // Make the soap call.
                    androidHttpTransport.call(SOAP_ACTION, envelope);

                    // Get the SoapResult from the envelope body.
                    resultRequestSOAP = (SoapObject) envelope.bodyIn;

                    SoapObject nameResult = (SoapObject) resultRequestSOAP
                            .getProperty(0);
                    int count = nameResult.getPropertyCount();
                    StringBuilder stringBuilder = new StringBuilder();
                    /*
                     * Retrieve one property from the complex SoapObject
                     * response
                     */
                    for (int i = 0; i < count - 1; i++) {
                        SoapObject simpleSuggestion = (SoapObject) nameResult
                                .getProperty(i);
                        stringBuilder.append(simpleSuggestion.getProperty(
                                "accountNumber").toString());
                        stringBuilder.append("\n");
                    }
                    

                    /** Show the suggestions in a text area field called
                    * lblStatus */
                   
                } catch (Exception aE) {
                    System.out.println(aE.toString());
                    aE.printStackTrace();
                }
            }
        });
		}



	
	@Override
	public void onGetBuildType(String result) {
		String response = result;
		try {
			BufferedReader br = new BufferedReader(new StringReader(response));
			InputSource isr = new InputSource(br);
			GetAccountParse parse = new GetAccountParse();
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser sp = factory.newSAXParser();
			XMLReader reader = sp.getXMLReader();
			reader.setContentHandler(parse);
			reader.parse(isr);
			accountdisplaylist=(ArrayList<GetAccountStatement>)GetAccountParse.accountstatementlist;
			
			Intent intent= new Intent(AccountSummary.this,BalanceDisplay.class);
			startActivity(intent);
			
			
		}catch(Exception e){
			
		}
			
		
	}


	private void updateLabel() {

		String myFormat = "yyyy-MM-dd"; 
		SimpleDateFormat sdf = new SimpleDateFormat(myFormat);

		fromdate.setText(sdf.format(myCalendar.getTime()));


	}
	private void updateLabeltodate() {

		String myFormat = "yyyy-MM-dd"; 
		SimpleDateFormat sdf = new SimpleDateFormat(myFormat);


		todate.setText(sdf.format(myCalendar.getTime()));
	}









}




