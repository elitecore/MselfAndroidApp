package com.elitecore.netvertex_LTE_project.Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.elitecore.netvertex_LTE_project.OnTaskComplete;

public class PaymentBackgroundTask extends AsyncTask<String, Integer, String> {

	private ProgressDialog dialog;
	private Context context;
	private String response;
	OnTaskComplete callBack;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public PaymentBackgroundTask(Context context) {
		this.context = context;

	}

	protected void onPreExecute() {
		dialog = ProgressDialog.show(context, "Processing", "Please Wait");

	}

	protected String doInBackground(String... params) {
		postData(params[0]);
		return response;
	}

	protected void onPostExecute(String result) {
		if (dialog.isShowing()) {
			dialog.dismiss();
		}
		callBack.onGetBuildType(result);
	}

	public void postData(String valueIWantToSend) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(
				"https://www.billdesk.com/pgidsk/PGIMerchantPayment");
		try {
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs
					.add(new BasicNameValuePair(
							"msg00",
							"IDEAWIFI|1399635610098|NA|5902.75|NA|NA|NA|INR|NA|R|ideawifi|NA|NA|F|008016000002|NA|NA|NA|NA|NA|NA|http://idea.datawsc.crestelsqa.in:20081/servlet/DATAService?ECID=ZIV7-FZTE-7MQQ-TKF4-VZDO-894E|3225546997"));
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			HttpResponse response = httpclient.execute(httppost);

		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
		} catch (IOException e) {
			// TODO Auto-generated catch block
		}
	}

}
